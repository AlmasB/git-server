# LearnJavaGameDev
A collection of game development tutorials compiled into a short syllabus
