package com.almasb.countdown;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Algorithm adapted from Mathias Panzenb�ck's js implementation
 *
 *
 * @author Almas Baimagambetov (ab607@uni.brighton.ac.uk)
 * @version 1.0
 *
 */
public class NumbersMain {

    public static void main(String[] args) {
        long start = System.nanoTime();

        target = 320;

        //int[] numbers = new int[] {75, 50, 2, 3, 8, 7};

        List<Integer> numbers = Arrays.asList(50, 4, 6, 1, 8, 6);

        Collections.sort(numbers);

        solutions(numbers);

        System.out.printf("Took: %.3f sec", (System.nanoTime() - start) / 1000000000.0);
    }

    public enum Operator {
        ADD("+", 0), SUB("-", 1), MUL("*", 3), DIV("/", 2);

        public final String op;
        public final int precedence;

        private Operator(String symbol, int precedence) {
            this.op = symbol;
            this.precedence = precedence;
        }
    }

    private static class Expr {
        protected int precedence;
        protected int value;
        protected String op, id;

        protected int used;

        protected Expr left, right;

        public Expr(Operator operator, Expr left, Expr right) {
            switch (operator) {
                case ADD:
                    value = left.value + right.value;
                    break;
                case DIV:
                    value = left.value / right.value;
                    break;
                case MUL:
                    value = left.value * right.value;
                    break;
                case SUB:
                    value = left.value - right.value;
                    break;
            }

            op = operator.op;
            precedence = operator.precedence;

            this.left = left;
            this.right = right;
            this.used = left.used | right.used;
            this.id = toID();
        }

        public Expr(int value) {
            op = "$";
            precedence = 4;
            this.value = value;
            this.id = toID();
        }

        @Override
        public String toString() {
            return left.toStringUnder(precedence) + " " + op + " " + right.toStringUnder(precedence);
        }

        public String toStringUnder(int precedence) {
            if (precedence > this.precedence)
                return "(" + toString() + ")";
            else
                return toString();
        }

        public String toID() {
            return "(" + left.toID() + op + right.toID() + ")";
        }
    }

    private static class Val extends Expr {
        private int index;

        public Val(int value, int index) {
            super(value);
            this.index = index;
            this.used = 1 << index;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        @Override
        public String toID() {
            return toString();
        }
    }

    private static boolean isNormalizedAdd(Expr left, Expr right) {
        if (right.op.equals("+") || right.op.equals("-"))
            return false;

        if (left.op.equals("+"))
            return left.right.value <= right.value;
        else if (left.op.equals("-"))
            return false;
        else
            return left.value <= right.value;
    }

    private static boolean isNormalizedSub(Expr left, Expr right) {
        if (right.op.equals("+") || right.op.equals("-"))
            return false;

        if (left.op.equals("-"))
            return left.right.value <= right.value;
        else
            return true;
    }

    private static boolean isNormalizedMul(Expr left, Expr right) {
        if (right.op.equals("*") || right.op.equals("/"))
            return false;

        if (left.op.equals("*"))
            return left.right.value <= right.value;
        else if (left.op.equals("/"))
            return false;
        else
            return left.value <= right.value;
    }

    private static boolean isNormalizedDiv(Expr left, Expr right) {
        if (right.op.equals("*") || right.op.equals("/"))
            return false;

        if (left.op.equals("/"))
            return left.right.value <= right.value;
        else
            return true;
    }

    private static void make(Expr a, Expr b) {
        if (isNormalizedAdd(a, b)) {
            functionA(new Expr(Operator.ADD, a, b));
        }
        else if (isNormalizedAdd(b, a)) {
            functionA(new Expr(Operator.ADD, b, a));
        }

        if (a.value != 1 && b.value != 1) {
            if (isNormalizedMul(a, b)) {
                functionA(new Expr(Operator.MUL, a, b));
            }
            else if (isNormalizedMul(b, a)) {
                functionA(new Expr(Operator.MUL, b, a));
            }
        }

        if (a.value > b.value) {
            if (isNormalizedSub(a, b)) {
                functionA(new Expr(Operator.SUB, a, b));
            }

            if (b.value != 1 && a.value % b.value == 0 && isNormalizedDiv(a, b)) {
                functionA(new Expr(Operator.DIV, a, b));
            }
        }
        else if (b.value > a.value) {
            if (isNormalizedSub(b, a)) {
                functionA(new Expr(Operator.SUB, b, a));
            }

            if (a.value != 1 && b.value % a.value == 0 && isNormalizedDiv(b, a)) {
                functionA(new Expr(Operator.DIV, b, a));
            }
        }
        else if (b.value != 1) {
            if (isNormalizedDiv(a, b)) {
                functionA(new Expr(Operator.DIV, a, b));
            }
            else if (isNormalizedDiv(b, a)) {
                functionA(new Expr(Operator.DIV, b, a));
            }
        }
    }

    private static void functionA(Expr expr) {
        if (expr.value == target) {
            functionB(expr);
        }
        else if (hasroom) {
            values.add(expr);
        }
    }

    private static void functionB(Expr expr) {
        System.out.println(++outIndex + ". " + expr.toString());
    }

    static boolean hasroom = false;
    static int target;
    static List<Expr> values = new ArrayList<Expr>();
    static int outIndex = 0;

    private static void solutions(List<Integer> numbers) {
        int numcnt = numbers.size();
        int full_usage = ~(~0 << numcnt);


        for (int i = 0; i < numbers.size(); i++) {
            values.add(new Val(numbers.get(i), i));
        }

        for (Expr v : values) {
            if (v.value == target) {
                functionB(v);
                break;
            }
        }

        int lower = 0;
        int upper = numcnt;

        while (lower < upper) {
            for (int i = lower; i < upper; i++) {
                Expr v = values.get(i);

                for (int j = 0; j < i; j++) {
                    Expr v2 = values.get(j);

                    if ((v2.used & v.used) == 0) {
                        hasroom = (v2.used | v.used) != full_usage;

                        make(v2, v);
                    }
                }
            }

            lower = upper;
            upper = values.size();
        }
    }
}
