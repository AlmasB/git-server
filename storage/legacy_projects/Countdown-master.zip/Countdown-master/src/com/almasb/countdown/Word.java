package com.almasb.countdown;

import java.util.ArrayList;
import java.util.Iterator;

public class Word {

    private String word;

    public Word(String word) {
        this.word = word;
    }

    public boolean consistsOf(String letters) {
        ArrayList<Character> lettersList = new ArrayList<Character>();
        for (char c : letters.toCharArray())
            lettersList.add(c);

        for (char c : word.toCharArray()) {
            boolean found = false;
            for (Iterator<Character> it = lettersList.iterator(); it.hasNext(); ) {
                if (c == it.next()) {
                    found = true;
                    it.remove();
                    break;
                }
            }

            if (!found)
                return false;
        }

        return true;
    }

    @Override
    public String toString() {
        return word;
    }
}
