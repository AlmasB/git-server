package com.almasb.countdown;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);

    private static List<Word> words = new ArrayList<Word>();
    private static HashMap<Word, Integer> occurrences = new HashMap<Word, Integer>();

    public static void main(String[] args) throws Exception {

        read("common.txt");
        read("frequent.txt");
        read("office.txt");
        read("often.txt");
        read("official.txt");
        read("single.txt");
        read("words.txt");

        String input = "";
        while (!input.equals("END")) {
            occurrences.clear();
            System.out.println("Enter letters");

            input = scanner.nextLine();

            for (Word word : words) {
                if (word.consistsOf(input) && word.toString().length() > 4) {
                    occurrences.put(word, word.toString().length());
                    System.out.println(word.toString().length() + ": " + word);
                }
            }
        }
    }

    private static void read(String name) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get("res/" + name));

        for (String word : lines) {
            words.add(new Word(word));
        }
    }
}
