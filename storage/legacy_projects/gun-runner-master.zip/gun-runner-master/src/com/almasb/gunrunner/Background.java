package com.almasb.gunrunner;

import com.almasb.android.io.Resources;
import com.almasb.common.animation.AnimatedObject;
import com.almasb.common.animation.Animation;
import com.almasb.common.animation.Animation.Type;
import com.almasb.common.animation.AnimatorThread;
import com.almasb.common.animation.ValueAnimation;
import com.almasb.common.graphics.Dimension2D;
import com.almasb.common.graphics.Drawable;
import com.almasb.common.graphics.GraphicsContext;
import com.almasb.common.graphics.Rect2D;

public class Background implements Drawable, AnimatedObject {
    
    private final int APP_W, APP_H;
    
    private int spriteID, spriteW, spriteH;
    @SuppressWarnings("unused")
    private int bgOffset = 0, speed = 0;
    
    private Rect2D[] sources;
    private Rect2D[] destinations;
    
    private int fullImages, pixelsLeft, rows, oneRow;
    
    public Background(int spriteID, int appW, int appH) {
        APP_W = appW;
        APP_H = appH;
        
        this.spriteID = spriteID;
        Dimension2D size = Resources.getImageDimension(spriteID);
        spriteW = size.getWidth();
        spriteH = size.getHeight();
        
        fullImages = APP_W / spriteW;
        pixelsLeft = APP_W % spriteW;
        
        rows = APP_H / spriteH + (APP_H % spriteH > 0 ? 1 : 0);

        oneRow = 1 + fullImages + (pixelsLeft > 0 ? 1 : 0);
        
        sources = new Rect2D[oneRow * rows];
        destinations = new Rect2D[sources.length];
        
        for (int i = 0; i < sources.length; i++) {
            sources[i] = new Rect2D(0, 0, 0, 0);
            destinations[i] = new Rect2D(0, 0, 0, 0);
        }
        
        calculatePosition();
    }

    public void setSpeed(int value) {
        speed = value;
    }
    
    public int getOffset() {
        return bgOffset;
    }
    
    private void calculatePosition() {
        int i = 0;
        for (int j = 0; j < rows; j++) {
            int h = (rows - 1 == j && APP_H % spriteH != 0 ? APP_H % spriteH : Math.min(APP_H, spriteH));
            
            sources[i].set(bgOffset, 0, Math.min(bgOffset + APP_W, spriteW) - bgOffset, h);
            destinations[i].set(0, j * spriteH, sources[i].getWidth(), sources[i].getHeight());
            
            pixelsLeft = APP_W - sources[i].getWidth();
            
            i++;
            
            for (int i2 = 1; i2 < oneRow; i2++) {
                boolean lastLoop = oneRow - 1 == i2;
                
                sources[i].set(0, 0, lastLoop ? pixelsLeft : spriteW, h);
                destinations[i].set(destinations[i-1].getRight(), j * spriteH, sources[i].getWidth(), sources[i].getHeight());
                
                pixelsLeft -= sources[i].getWidth();
                
                i++;
            } 
        }
    }
    
    @Override
    public void animate() {
        Animation anim = new ValueAnimation(this, 5000, 0, spriteW, Type.REPEAT);
        AnimatorThread.submit(anim);
    }
    
    @Override
    public void onAnimate(float value) {
        bgOffset = Math.round(value);
        calculatePosition();
    }
    
    @Override
    public void draw(GraphicsContext g) {
        for (int i = 0; i < sources.length; i++)
            g.drawImage(spriteID, sources[i], destinations[i]);
    }

    @Override
    public int getX() {
        return 0;
    }

    @Override
    public int getY() {
        return 0;
    }

    @Override
    public void onAnimationEnd() {
        // TODO Auto-generated method stub
    }

    @Override
    public void onAnimationStart() {
        // TODO Auto-generated method stub
    }
}
