package com.almasb.gunrunner;

import static com.almasb.gunrunner.Const.GAME_UPDATE_DELAY;

import java.util.*;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.almasb.gunrunner.entity.*;
import com.almasb.android.graphics.AndroidGraphicsContext;
import com.almasb.android.io.Resources;
import com.almasb.common.animation.AnimatorThread;
import com.almasb.common.graphics.Color;
import com.almasb.common.graphics.Drawable;
import com.almasb.common.graphics.ProgressBar;
import com.almasb.spacerunner.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

@SuppressLint("ClickableViewAccessibility")
public class GameView extends View implements OnTouchListener {
    
    public enum UserEvent {
        NONE, UP, DOWN
    }
    
    private AndroidGraphicsContext gContext;
    private final int APP_W, APP_H;
    
    private ProgressBar progressBar = new ProgressBar();
    
    private DispatcherTask dispatcher;
    private GameModel model;
    private Player player;
    private List<Drawable> drawables;
    
    public GameView(Context context) {
        super(context);

        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        APP_W = metrics.widthPixels;
        APP_H = metrics.heightPixels;
        
        setFocusable(true);
        setFocusableInTouchMode(true);
        setOnTouchListener(this);
        
        progressBar.setMessage("Loading Resources...");
        
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                AnimatorThread.init(17);
                Resources.init(getContext(), R.drawable.class, R.raw.class);
                
                progressBar.setValue(50);
                
                model = new GameModel(APP_W, APP_H);
                player = model.getPlayer();
                drawables = model.getDrawables();
                model.start();  // starts the game loop
                
                progressBar.setValue(100);
                progressBar.setEnabled(false);
            }
        });
        t.start();
    }   
    
    @Override
    protected void onDraw(Canvas g) {
        if (gContext == null) {
            Paint p = new Paint();
            p.setAntiAlias(true);
            p.setTextSize(APP_W > 600 ? 40 : 30);
            gContext = new AndroidGraphicsContext(g, p);
        }
        else {
            gContext.setCanvas(g);
        }
        
        // draw event fires up pretty early, so consume it
        // and display a progress bar until we are ready to show the game
        if (model == null || !model.isGameInited()) {
            progressBar.draw(gContext);
            invalidate();
            return;
        }
        
        // actual drawing
        synchronized (model.getLock()) {                 
            gContext.setRenderXY(player.getX() - 10, 0);
            
            // now draw objects
            for (Drawable d : drawables)
                d.draw(gContext);
            
            if (player.hasShield()) {
                gContext.setColor(Color.BLUE);
                gContext.drawCircle(player.getX() - gContext.getRenderX(), player.getY() - gContext.getRenderY(), player.getWidth() / 2);
            }
            
            // draw debug info
            /*debug = g.isHardwareAccelerated() + ""
                    + "Free: " + Runtime.getRuntime().freeMemory() / 1000 + " KB "
                    + "Total: " + Runtime.getRuntime().totalMemory() / 1000 + " KB "
                    + "Max: " + Runtime.getRuntime().maxMemory() / 1000 + " KB ";
            
            gContext.getPaint().setColor(Color.WHITE);
            gContext.getGraphics().drawText("DEBUG: " + debug, 100, 100, gContext.getPaint());
            gContext.getGraphics().drawText("DRAWING: " + frames + " fps", 100, 200, gContext.getPaint());
            gContext.getGraphics().drawText("UPDATING: " + (int) (SECOND_IN_NANO / (fpsCounter.count(timeTookUpdate) + 0.0001f)) + " fps", 100, 300, gContext.getPaint());*/
            
            // render UI
            gContext.setColor(Color.WHITE);
            gContext.drawString("SCORE: " + model.getScore(), APP_W - 100 - gContext.getStringWidth("SCORE: " + model.getScore()), 100);
            gContext.drawString(model.getMessage(), APP_W / 2 - gContext.getStringWidth(model.getMessage()) / 2, APP_H / 2);
            
            String hp = "HP: " + player.getHP();
            String dmg = "Damage: " + player.getDamage();
            
            gContext.drawString(hp, APP_W - gContext.getStringWidth(hp) - 20, APP_H - 50);
            gContext.drawString(dmg, APP_W - gContext.getStringWidth(dmg) - 20, APP_H - 100);
            
            //framesCounter++;
            
            if (model.isGameRunning())
                invalidate();
        }
    } 
    
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (dispatcher == null) {
            dispatcher = new DispatcherTask(event);
            // start dispatcher thread and dispatching
            new ScheduledThreadPoolExecutor(1).scheduleAtFixedRate(dispatcher, 0, GAME_UPDATE_DELAY, TimeUnit.NANOSECONDS);
        }
        
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            dispatcher.startDispatch();
        }
        else if (event.getAction() == MotionEvent.ACTION_UP) {
            dispatcher.stopDispatch();
        }
        
        return true;
    }
    
    private class DispatcherTask implements Runnable {
        
        private MotionEvent e;
        
        private boolean dispatch = false;
        
        public DispatcherTask(MotionEvent e) {
            this.e = e;
        }
        
        public void startDispatch() {
            dispatch = true;
        }
        
        public void stopDispatch() {
            dispatch = false;
        }
        
        @Override
        public void run() {
            if (dispatch) {
                if (e.getY() < player.getY() && player.getY() > 0) {
                    model.setUserEvent(UserEvent.UP);
                }
                else if (e.getY() > player.getY() + player.getHeight() && player.getY() + player.getHeight() < APP_H) {
                    model.setUserEvent(UserEvent.DOWN);
                }
            }
            else {
                model.setUserEvent(UserEvent.NONE);
            }
        }
    }
}
