package com.almasb.gunrunner.entity;

import com.almasb.gunrunner.Const;
import com.almasb.spacerunner.R;
import com.almasb.gunrunner.entity.Bonus.BonusEffect;

public class Player extends GameObject {
    
    private int fireRate = Const.PLAYER_BASE_FIRE_RATE;
    private int damage = Const.ENEMY_BASE_DAMAGE;
    
    private boolean doubleStrike = false, tripleStrike = false,
            ricochet = false, shield = false;
    
    public Player(int x, int y) {
        super(x, y, R.drawable.sprite_player);
        this.hp = Const.PLAYER_HP;
        this.dx = Const.PLAYER_SPEED;
    }
    
    public void applyBonus(Bonus b) {
        switch (b.getEffect()) {
            case HP:
                hp++;
                break;
            case DAMAGE:
                damage++;
                break;
            case FIRE_RATE:
                fireRate++;
                break;
            
            // temporary
            case DOUBLE_STRIKE:
                doubleStrike = true;
                break;
            case TRIPLE_STRIKE:
                tripleStrike = true;
                break;
            case RICOCHET:
                ricochet = true;
                break;
            case SHIELD:
                shield = true;
                break;
            default:
                break;
        }
    }

    public void removeBonusEffect(BonusEffect b) {
        // only remove temporary bonuses
        switch (b) {
            case DOUBLE_STRIKE:
                doubleStrike = false;
                break;
            case TRIPLE_STRIKE:
                tripleStrike = false;
                break;
            case RICOCHET:
                ricochet = false;
                break;
            case SHIELD:
                shield = false;
                break;
            default:
                break;
        }
    }
    
    public int getFireRate() {
        return fireRate;
    }
    
    public int getDamage() {
        return damage;
    }
    
    public boolean hasDoubleStrike() {
        return doubleStrike;
    }
    
    public boolean hasTripleStrike() {
        return tripleStrike;
    }
    
    public boolean hasRicochet() {
        return ricochet;
    }
    
    public boolean hasShield() {
        return shield;
    }
}
