package com.almasb.gunrunner.entity;

import com.almasb.spacerunner.R;

public class Bullet extends GameObject {
    public Bullet(int x, int y) {
        super(x, y, R.drawable.sprite_bullet);
    }
}
