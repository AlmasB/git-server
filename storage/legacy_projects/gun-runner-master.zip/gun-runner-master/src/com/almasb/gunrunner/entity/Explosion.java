package com.almasb.gunrunner.entity;

import com.almasb.android.io.Resources;
import com.almasb.common.animation.AnimatedObject;
import com.almasb.common.animation.Animation;
import com.almasb.common.animation.AnimatorThread;
import com.almasb.common.graphics.Dimension2D;
import com.almasb.common.graphics.GraphicsContext;
import com.almasb.common.graphics.Rect2D;
import com.almasb.gunrunner.GameView;
import com.almasb.spacerunner.R;

public class Explosion extends GameObject implements AnimatedObject {

    private Rect2D src = new Rect2D(0, 0, 0, 0), dst = new Rect2D(0, 0, 0, 0);
    private int imageWidth, imageHeight;
    
    public Explosion(int x, int y) {
        super(x, y, R.drawable.animation_explosion);
        imageWidth = imageHeight = Resources.getImageDimension(spriteID).getWidth() / 5;
    }

    @Override
    public void draw(GraphicsContext g) {
        if (!alive) return;

        int tmpX = x - g.getRenderX();
        int tmpY = y - g.getRenderY();
        dst.set(tmpX, tmpY, imageWidth, imageHeight);
        g.drawImage(spriteID, src, dst);
    }
    
    @Override
    public void animate() {
        Animation anim = new Animation(this, 1000);
        AnimatorThread.submit(anim);
    }

    @Override
    public void onAnimate(float percent) {
        int spriteIndex = Math.round(percent*24);
        // sprite has 5 rows and 5 columns
        int tmpX = (spriteIndex % 5) * imageWidth;
        int tmpY = (spriteIndex / 5) * imageHeight;
        
        src.set(tmpX, tmpY, imageWidth, imageHeight);
    }

    @Override
    public void onAnimationEnd() {
        setAlive(false);
        src.set(0, 0, 0, 0);
    }

    @Override
    public void onAnimationStart() {
        // TODO Auto-generated method stub 
    }
}
