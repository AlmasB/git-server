package com.almasb.gunrunner.entity;

import com.almasb.common.animation.AnimatedObject;
import com.almasb.common.animation.Animation;
import com.almasb.common.animation.AnimatorThread;
import com.almasb.common.animation.ValueAnimation;
import com.almasb.gunrunner.Const;
import com.almasb.spacerunner.R;

public class Bonus extends GameObject implements AnimatedObject {
    
    public enum BonusEffect {
        // permanent
        HP(R.drawable.sprite_bonus_hp), DAMAGE(R.drawable.sprite_bonus_damage), FIRE_RATE(R.drawable.sprite_bonus_firerate),
        // temporary
        DOUBLE_STRIKE(R.drawable.sprite_bonus_double), TRIPLE_STRIKE(R.drawable.sprite_bonus_triple), 
        RICOCHET(R.drawable.sprite_bonus_ricochet), SHIELD(R.drawable.sprite_bonus_shield);
        
        public final int resID;
        
        private BonusEffect(int id) {
            this.resID = id;
        }
    }
    
    private BonusEffect effect = BonusEffect.HP;
    private boolean isAnimating = false;

    public Bonus() {
        super(0, 0, R.drawable.sprite_bonus_hp);
    }
    
    public void setEffect(BonusEffect effect) {
        this.effect = effect;
    }
    
    public BonusEffect getEffect() {
        return effect;
    }
    
    public boolean isAnimating() {
        return isAnimating;
    }

    @Override
    public void animate() {
        Animation anim = new ValueAnimation(this, 1000, y, -height);
        AnimatorThread.submit(anim);
        isAnimating = true;
    }

    @Override
    public void onAnimate(float value) {
        y = Math.round(value);
        x += Const.PLAYER_SPEED * 2;
    }

    @Override
    public void onAnimationEnd() {
        setAlive(false);
        isAnimating = false;
    }

    @Override
    public void onAnimationStart() {
    }
}
