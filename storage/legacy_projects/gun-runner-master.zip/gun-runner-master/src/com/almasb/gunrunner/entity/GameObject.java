package com.almasb.gunrunner.entity;

import com.almasb.android.io.Resources;
import com.almasb.common.graphics.Dimension2D;
import com.almasb.common.graphics.Drawable;
import com.almasb.common.graphics.GraphicsContext;
import com.almasb.common.graphics.GraphicsContext.Flip;

public abstract class GameObject implements Drawable {

    protected int x, y, width, height;
    public float dx = 0.0f, dy = 0.0f;
    
    protected int hp = 0;
    protected boolean alive = true;
    
    protected int spriteID;
    private boolean spriteFlipped = false;
    
    public GameObject(int x, int y, int spriteID) {
        this.x = x;
        this.y = y;
        this.spriteID = spriteID;
        Dimension2D size = Resources.getImageDimension(spriteID);
        this.width = size.getWidth();
        this.height = size.getHeight();
    }
    
    public void setSpriteFlipped(boolean b) {
        spriteFlipped = b;
    }
    
    public void move() {
        x += dx;
        y += dy;
    }
    
    public void takeHit(int damage) {
        hp -= damage;
        if (hp <= 0)
            setAlive(false);
    }
    
    public boolean isColliding(GameObject other) {
        return x < other.x + other.width && other.x < x + width
                && y < other.y + other.height && other.y < y + height;
    }
    
    public void setAlive(boolean b) {
        alive = b;
    }
    
    public boolean isAlive() {
        return alive;
    }
    
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public int getHP() {
        return hp;
    }
    
    public void setSpriteID(int resID) {
        this.spriteID = resID;
    }
    
    @Override
    public void draw(GraphicsContext g) {
        if (!alive) return;
        
        int tmpX = getX() - g.getRenderX();
        int tmpY = getY() - g.getRenderY();
        
        g.drawImage(spriteID, tmpX, tmpY, spriteFlipped ? Flip.HORIZONTAL : Flip.NONE);
    }
}
