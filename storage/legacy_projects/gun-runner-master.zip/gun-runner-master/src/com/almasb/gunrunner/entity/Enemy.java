package com.almasb.gunrunner.entity;

import com.almasb.android.io.Resources;
import com.almasb.common.graphics.Color;
import com.almasb.common.graphics.Dimension2D;
import com.almasb.common.graphics.GraphicsContext;
import com.almasb.gunrunner.Const;
import com.almasb.gunrunner.GameView;
import com.almasb.spacerunner.R;

public class Enemy extends GameObject {
    
    private int level = 1;
    
    public Enemy(int x, int y) {
        super(x, y, R.drawable.sprite_enemy_1);
        this.hp = Const.ENEMY_BASE_HP;
    }
    
    public void setLevel(int level) {
        this.level = level;
        switch (level) {
            case 1:
                setSpriteID(R.drawable.sprite_enemy_1);
                break;
            case 2:
                setSpriteID(R.drawable.sprite_enemy_2);
                break;
            case 3:
                setSpriteID(R.drawable.sprite_enemy_3);
                break;
            case 4:
                setSpriteID(R.drawable.sprite_enemy_4);
                break;
            case 5:
                setSpriteID(R.drawable.sprite_enemy_5);
                break;
            case 6:
                setSpriteID(R.drawable.sprite_enemy_6);
                break;
            case 7:
                setSpriteID(R.drawable.sprite_enemy_7);
                break;
            case 8:
                setSpriteID(R.drawable.sprite_enemy_8);
                break;
            case 9:
                setSpriteID(R.drawable.sprite_enemy_9);
                break;
            case 10:
                setSpriteID(R.drawable.sprite_enemy_10);
                break;
        }
        
        Dimension2D size = Resources.getImageDimension(spriteID);
        this.width = size.getWidth();
        this.height = size.getHeight();
        restoreHP();
    }
    
    public void restoreHP() {
        this.hp = 2 + (level-1) * Const.ENEMY_HP_PER_LEVEL;
    }
    
    public int getLevel() {
        return level;
    }
    
    @Override
    public void draw(GraphicsContext g) {
        if (!alive) return;
        
        super.draw(g);
        g.setColor(Color.RED);
        
        int tmpX = x - g.getRenderX();
        int tmpY = y - g.getRenderY() + height;
        
        g.fillRect(tmpX, tmpY, (int)(width * hp / (1.0f*(2 + (level-1) * Const.ENEMY_HP_PER_LEVEL))), 5);
    }
}
