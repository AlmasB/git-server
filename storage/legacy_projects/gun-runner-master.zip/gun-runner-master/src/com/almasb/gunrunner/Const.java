package com.almasb.gunrunner;

/**
 * Holds game constants
 * 
 * @author Almas
 *
 */
public class Const {
    public static final long SECOND_IN_NANO = 1000000000L;
    
    public static final int GAME_UPDATE_RATE = 60;
    public static final long GAME_UPDATE_DELAY = SECOND_IN_NANO / GAME_UPDATE_RATE;
    
    public static final int PLAYER_HP = 15;
    public static final float PLAYER_SPEED = 10.0f;
    public static final int PLAYER_BASE_FIRE_RATE = 1;
    public static final int PLAYER_BASE_DAMAGE = 1;
    
    public static final int ENEMY_BASE_HP = 2;
    public static final int ENEMY_HP_PER_LEVEL = 4;
    public static final int ENEMY_MAX = 5;
    public static final int ENEMY_BASE_DAMAGE = 1;
    public static final float ENEMY_SPAWN_BONUS_CHANCE = 0.2f;  // 0.0f - 0%, 1.0f - 100%
    
    public static final int BULLET_MAX = 30;
    public static final float BULLET_SPEED_PLAYER = 25.0f;
    public static final float BULLET_SPEED_ENEMY = -10.0f;
    
    public static final int BONUS_MAX = 5;
    public static final long BONUS_TEMPORARY_DURATION = 5 * SECOND_IN_NANO;
    
    public static final int DECOR_MAX = 15;
    
    public static final int SCORE_KILL = 500;
    public static final int SCORE_BONUS = 1000;
    public static final int SCORE_LEVEL = 1500;
    public static final float SCORE_BASE_MODIFIER = 1.0f;   // 1.0f - 100%
    public static final float SCORE_INCREMENT_MODIFIER = 0.125f;
    
    /**
     * How much time you have in nanoseconds between killing
     * enemies before score modifier resets to
     * {@link SCORE_BASE_MODIFIER}
     */
    public static final long SCORE_TIME_MODIFIER = 2 * SECOND_IN_NANO;
}
