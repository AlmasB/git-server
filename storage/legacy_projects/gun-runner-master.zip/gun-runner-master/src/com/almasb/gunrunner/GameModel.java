package com.almasb.gunrunner;

import static com.almasb.gunrunner.Const.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.almasb.android.audio.AndroidAudioPlayer;
import com.almasb.common.audio.AudioPlayer;
import com.almasb.common.graphics.Drawable;
import com.almasb.common.util.FPSCounter;
import com.almasb.gunrunner.GameView.UserEvent;
import com.almasb.gunrunner.entity.Bonus;
import com.almasb.gunrunner.entity.Bullet;
import com.almasb.gunrunner.entity.Enemy;
import com.almasb.gunrunner.entity.Explosion;
import com.almasb.gunrunner.entity.Player;
import com.almasb.gunrunner.entity.Bonus.BonusEffect;
import com.almasb.spacerunner.R;

public class GameModel {

    private enum Sound {
        SHOOT(R.raw.sound_shoot), ENEMY_SHOOT(R.raw.sound_enemy_shoot),
        EXPLOSION(R.raw.sound_explosion), POWERUP(R.raw.sound_powerup),
        LEVELUP(R.raw.sound_levelup), PLAYER_HURT(R.raw.sound_player_hurt),
        DEFLECT(R.raw.sound_deflect);
        
        public final int resID;
        private Sound(int resID) {
            this.resID = resID;
        }
    }
    
    private AudioPlayer audioPlayer = new AndroidAudioPlayer(); 
    
    private Background background, background2, background3;
    private Player player = new Player(10, 0);
    private List<Enemy> enemies = new ArrayList<Enemy>(ENEMY_MAX);
    private List<Bullet> playerBullets = new ArrayList<Bullet>(BULLET_MAX);
    private List<Bullet> enemyBullets = new ArrayList<Bullet>(BULLET_MAX);
    private List<Explosion> explosions = new ArrayList<Explosion>(ENEMY_MAX);
    private List<Bonus> bonuses = new ArrayList<Bonus>(BONUS_MAX);
    
    private ScheduledThreadPoolExecutor workerThread = new ScheduledThreadPoolExecutor(1);
    private ScheduledThreadPoolExecutor mainLoopThread = new ScheduledThreadPoolExecutor(1);
    private ScheduledFuture<?> mainLoop;
    private Random random = new Random();

    private long timeLastShoot = System.nanoTime(), timeLastEnemyKilled = 0,
            timeTookUpdate = 0;
    
    private int frames = 0, framesCounter = 0;
    
    private FPSCounter fpsCounter = new FPSCounter();
    
    private int score = 0, level = 1;
    private float scoreModifier = SCORE_BASE_MODIFIER;
    private String debug = "", message = "";
    private boolean gameInited = false;
    private boolean running = true;
    
    private UserEvent event = UserEvent.NONE;
    
    private Object lock = new Object();
    
    private final int APP_W, APP_H;
    
    public GameModel(int appW, int appH) {
        APP_W = appW;
        APP_H = appH;
        init();
    }
    
    private void init() {
        // init and cache objects
        background = new Background(R.drawable.bg_0, APP_W, APP_H);
        background2 = new Background(R.drawable.bg_1, APP_W, APP_H);
        background3 = new Background(R.drawable.bg_2, APP_W, APP_H);
        
        background.setSpeed(1);
        background2.setSpeed(3);
        background3.setSpeed(5);
        
        for (int i = 0; i < ENEMY_MAX; i++) {
            Enemy e = new Enemy(0, 0);
            e.setAlive(false);
            enemies.add(e);
        }
        
        for (int i = 0; i < BULLET_MAX; i++) {
            Bullet b = new Bullet(0, 0);
            b.setAlive(false);
            playerBullets.add(b);
            
            b = new Bullet(0, 0);
            b.setSpriteFlipped(true);
            b.setAlive(false);
            enemyBullets.add(b);
        }
        
        for (int i = 0; i < ENEMY_MAX; i++) {
            Explosion e = new Explosion(0, 0);
            e.setAlive(false);
            explosions.add(e);
        }
        
        for (int i = 0; i < BONUS_MAX; i++) {
            Bonus b = new Bonus();
            b.setAlive(false);
            bonuses.add(b);
        }
    }
    
    public void start() {
        // schedule actions
        mainLoop = mainLoopThread.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                long ticks = System.nanoTime();
                
                synchronized (lock) {
                    update();
                }
                
                timeTookUpdate = System.nanoTime() - ticks;
            }
        }, 0, GAME_UPDATE_DELAY, TimeUnit.NANOSECONDS);
        
        workerThread.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                frames = framesCounter;
                framesCounter = 0;
                spawnEnemy();
            }
        }, 0, 1, TimeUnit.SECONDS);
        
        workerThread.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                spawnBonusRandom();
            }
        }, 0, 5, TimeUnit.SECONDS);
        
        workerThread.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                enemyShoot();
            }
        }, 0, 3, TimeUnit.SECONDS);
        
        // when finished
        background.animate();
        gameInited = true;
    }
    
    public void update() {
        processUserEvent();
        
        if (System.nanoTime() - timeLastShoot >= (SECOND_IN_NANO / Math.pow(player.getFireRate(), 0.33))) {
            shoot();
            timeLastShoot = System.nanoTime();
        }
        
        player.move();
        
        for (final Bonus b : bonuses) {
            if (!b.isAlive() || b.isAnimating()) continue;
            
            if (b.getX() + b.getWidth() < player.getX()) {
                b.setAlive(false);
                continue;
            }
            
            if (b.isColliding(player)) {
                player.applyBonus(b);
                addScore(SCORE_BONUS);
                b.animate();
                playSound(Sound.POWERUP);
                
                final BonusEffect effect = b.getEffect();
                workerThread.schedule(new Runnable() {
                    @Override
                    public void run() {
                        player.removeBonusEffect(effect);
                    }
                }, BONUS_TEMPORARY_DURATION, TimeUnit.NANOSECONDS);
            }
        }
        
        for (Bullet b : playerBullets) {
            if (!b.isAlive()) continue;
            
            b.move();
            if (b.getX() > player.getX() + APP_W) {
                b.setAlive(false);
                continue;
            }
            
            for (Enemy e : enemies) {
                if (!e.isAlive()) continue;
                
                if (e.getX() + e.getWidth() < player.getX()) {
                    e.setAlive(false);
                    continue;
                }
                
                if (b.isColliding(e)) {
                    if (!player.hasRicochet())
                        b.setAlive(false);
                    
                    e.takeHit(player.getDamage());
                    spawnExplosion(e.getX(), e.getY());
                    
                    if (System.nanoTime() - timeLastEnemyKilled < SCORE_TIME_MODIFIER) {
                        scoreModifier += SCORE_INCREMENT_MODIFIER;
                    }
                    else {
                        scoreModifier = SCORE_BASE_MODIFIER;
                    }
                    
                    timeLastEnemyKilled = System.nanoTime();
                    
                    addScore(SCORE_KILL * level);

                    if (random.nextFloat() <= ENEMY_SPAWN_BONUS_CHANCE) {
                        spawnBonus(e.getX(), e.getY());
                    }
                    break;
                }
            }
        }
        
        for (Bullet b : enemyBullets) {
            if (!b.isAlive()) continue;
            
            b.move();
            if (b.getX() + b.getWidth() < player.getX() + player.getWidth()) {
                b.setAlive(false);
                continue;
            }
            
            if (b.isColliding(player)) {
                b.setAlive(false);
                
                if (!player.hasShield()) {
                    player.takeHit((int)(Math.sqrt(ENEMY_BASE_DAMAGE * level)));
                    playSound(Sound.PLAYER_HURT);
                    if (!player.isAlive())
                        gameOver("You Lose");
                }
                else {
                    playSound(Sound.DEFLECT);
                }
            }
        }
    }

    public void shoot() {
        int numBullets = 1;
        if (player.hasTripleStrike()) {
            numBullets = 3;
        }
        else if (player.hasDoubleStrike()) {
            numBullets = 2;
        }
        
        for (Bullet b : playerBullets) {
            if (!b.isAlive()) {
                int h = 1;
                switch (numBullets) {
                    case 3:
                        h = 2;
                        break;
                    case 2:
                        h = 0;
                        break;
                }
                
                int w = player.getX() + (h == 1 ? player.getWidth() : player.getWidth() / 2);
                
                b.setXY(w, player.getY() + h * (player.getHeight() / 2) - b.getHeight() / 2);
                b.dx = BULLET_SPEED_PLAYER;

                if (player.hasRicochet()) {
                    b.setSpriteID(R.drawable.sprite_bullet_ricochet);
                }
                else {
                    b.setSpriteID(R.drawable.sprite_bullet);
                }
                
                b.setAlive(true);
                numBullets--;
                
                if (numBullets == 0)
                    break;
            }
        }
        
        playSound(Sound.SHOOT);
    }
    
    public void enemyShoot() {
        for (Enemy e : enemies) {
            if (!e.isAlive()) continue;
            
            for (Bullet b : enemyBullets) {
                if (!b.isAlive()) {
                    b.setXY(e.getX() - b.getWidth(), e.getY() + e.getHeight() / 2 - b.getHeight() / 2);
                    b.dx = BULLET_SPEED_ENEMY;
                    b.setAlive(true);
                    break;
                }
            }
        }
        
        playSound(Sound.ENEMY_SHOOT);
    }
    
    public void spawnEnemy() {
        // min spawn distance is APP_W, max = 2*APP_W     
        for (Enemy e : enemies) {
            if (!e.isAlive()) {
                e.setXY(player.getX() + random.nextInt(APP_W) + APP_W, random.nextInt(APP_H - e.getHeight()));
                e.restoreHP();
                e.setAlive(true);
                break;
            }
        }
    }
    
    public void spawnBonus(int x, int y) {
        for (Bonus b : bonuses) {
            if (!b.isAlive()) {
                b.setXY(x, y);
                BonusEffect[] effects = BonusEffect.values();
                b.setEffect(effects[random.nextInt(effects.length)]);
                b.setSpriteID(b.getEffect().resID);
                b.setAlive(true);
                break;
            }
        }
    }
    
    public void spawnBonusRandom() {
        spawnBonus(player.getX() + random.nextInt(APP_W) + APP_W, random.nextInt(APP_H - player.getHeight()));
    }
    
    public void spawnExplosion(int x, int y) {
        for (Explosion e : explosions) {
            if (!e.isAlive()) {
                e.setXY(x, y);
                e.setAlive(true);
                e.animate();    // start animation
                break;
            }
        }
        
        playSound(Sound.EXPLOSION);
    }
    
    public void playSound(Sound sound) {
        audioPlayer.playSound(sound.resID);
    }
    
    private void postMessage(String message) {
        this.message = message;
    }
    
    public void addScore(int value) {
        score += value * scoreModifier;
        if (score > 999999) {
            gameOver("Congratulations! You have completed Alpha version!");
            return;
        }
        
        if (score >= level * 100000) {
            level++;
            score += SCORE_LEVEL * scoreModifier;
            scoreModifier = SCORE_BASE_MODIFIER;
            playSound(Sound.LEVELUP);
            for (Enemy e : enemies) {
                e.setLevel(level);
            }
            postMessage("Level " + level);
            workerThread.schedule(new Runnable() {
                @Override
                public void run() {
                    postMessage("");
                }
            }, 2, TimeUnit.SECONDS);
        }
    }
    
    public void gameOver(String message) {
        mainLoop.cancel(false);
        workerThread.shutdownNow();
        postMessage(message);
        running = false;
    }
    
    public void setUserEvent(UserEvent event) {
        this.event = event;
    }
    
    private void processUserEvent() {
        if (event == UserEvent.UP) {
            player.dy = -10.0f;
        }
        else if (event == UserEvent.DOWN) {
            player.dy = 10.0f;
        }
        else {
            player.dy = 0.0f;
        }
    }
    
    public Object getLock() {
        return lock;
    }
    
    public boolean isGameInited() {
        return gameInited;
    }
    
    public Player getPlayer() {
        return player;
    }
    
    public boolean isGameRunning() {
        return running;
    }
    
    public int getScore() {
        return score;
    }
    
    public String getMessage() {
        return message;
    }
    
    public List<Drawable> getDrawables() {
        List<Drawable> list = new ArrayList<Drawable>();
        
        list.add(background);
        list.add(player);
        
        for (Drawable d : enemies)
            list.add(d);
        
        for (Drawable d : playerBullets)
            list.add(d);
        
        for (Drawable d : enemyBullets)
            list.add(d);
        
        for (Drawable d : explosions)
            list.add(d);
        
        for (Drawable d : bonuses)
            list.add(d);
        
        return list;
    }
}
