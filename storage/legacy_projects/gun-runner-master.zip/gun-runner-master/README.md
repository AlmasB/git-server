gun-runner
==========

a game where main char just runs and shoots
