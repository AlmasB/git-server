package uk.ac.brighton.uni.ab607.counterlogic;

public class Main {
    public static void main(String[] args) {
        Logic logic = new Logic();
        logic.readInput();

        logic.drawStateTable();
        logic.drawExcitationTable();

        logic.drawCounterStateTable();
        logic.drawKMap();
    }
}
