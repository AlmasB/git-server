package uk.ac.brighton.uni.ab607.counterlogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

// J - set, K - reset
public class Logic {

    private static final String ABC = "ABCDEF";

    private Scanner scanner = new Scanner(System.in);
    private ArrayList<String> inputList = new ArrayList<String>();

    private ArrayList<String> CS = new ArrayList<String>();
    private ArrayList<String> NS = new ArrayList<String>();

    public void drawStateTable() {
        System.out.println("J K State Table");
        System.out.println("J K | Q Q+");
        System.out.println("----|-----");
        System.out.println("0 0 | 0  0");
        System.out.println("0 0 | 1  1");
        System.out.println("----|-----");
        System.out.println("0 1 | 0  0");
        System.out.println("0 1 | 1  0");
        System.out.println("----|-----");
        System.out.println("1 0 | 0  1");
        System.out.println("1 0 | 1  1");
        System.out.println("----|-----");
        System.out.println("1 1 | 0  1");
        System.out.println("1 1 | 1  0");
        System.out.println();
    }

    public void drawExcitationTable() {
        System.out.println("J K Excitation Table");
        System.out.println("J K | Q Q+");
        System.out.println("----|-----");
        System.out.println("0 X | 0->0");
        System.out.println("1 X | 0->1");
        System.out.println("X 1 | 1->0");
        System.out.println("X 0 | 1->1");
        System.out.println();
    }

    public void readInput() {
        String input = "";

        while (true) {
            input = scanner.nextLine();
            if (input.equals("END"))
                break;
            inputList.add(input);
        }
    }

    public void drawCounterStateTable() {
        System.out.println("Counter State Table");
        int max = 0;
        for (String s : inputList) {
            int state = Integer.parseInt(s);
            if (state > max)
                max = state;
        }

        max = Integer.toBinaryString(max).length();
        for (int i = 0; i < max; i++) {
            System.out.print(ABC.charAt(i));
        }

        System.out.println(" | NS");

        for (int i = 0; i < inputList.size(); i++) {
            String bin = Integer.toBinaryString(Integer.parseInt(inputList.get(i)));
            while (bin.length() < max) {
                bin = "0" + bin;
            }

            CS.add(bin);

            System.out.print(bin + " | ");
            if (i + 1 < inputList.size()) {
                bin = Integer.toBinaryString(Integer.parseInt(inputList.get(i+1)));
            }
            else {
                bin = Integer.toBinaryString(Integer.parseInt(inputList.get(0)));
            }

            while (bin.length() < max) {
                bin = "0" + bin;
            }
            NS.add(bin);
            System.out.println(bin);
        }
        System.out.println();
    }

    private TreeMap<String, String> jMap = new TreeMap<String, String>();
    private TreeMap<String, String> kMap = new TreeMap<String, String>();

    public void drawKMap() {
        int max = CS.get(0).length();
        int second = max / 2;
        int first = max - second;


        for (int i1 = 0; i1 < max; i1++) {
            for (int i = 0; i < CS.size(); i++) {
                char a = CS.get(i).charAt(i1);
                char b = NS.get(i).charAt(i1);

                if (a == '0' && b == '0') {
                    jMap.put(CS.get(i), "0");
                    kMap.put(CS.get(i), "X");
                }
                else if (a == '0' && b == '1') {
                    jMap.put(CS.get(i), "1");
                    kMap.put(CS.get(i), "X");
                }
                else if (a == '1' && b == '0') {
                    jMap.put(CS.get(i), "X");
                    kMap.put(CS.get(i), "1");
                }
                else /* must be a == '1' && b == '1' */ {
                    jMap.put(CS.get(i), "X");
                    kMap.put(CS.get(i), "0");
                }
            }

            // draw J
            for (int i = 0; i < first; i++) {
                System.out.print(ABC.charAt(i));
            }
            System.out.print("\\");
            for (int i = first; i < max; i++) {
                System.out.print(ABC.charAt(i));
            }

            System.out.print("\t");

            if (second == 1)
                System.out.print("0\t1");
            else
                System.out.print("00\t01\t11\t10");

            System.out.println();


            for (int i = 0; i < Math.pow(2, first); i++) {
                String bin = toBinary(i, first);
                if (bin.equals("10"))
                    bin = "11";
                else if (bin.equals("11"))
                    bin = "10";

                System.out.print(bin + "|");
                if (second == 1) {
                    System.out.print("\t" + asString(jMap.get(bin + "0")));
                    System.out.print("\t" + asString(jMap.get(bin + "1")));
                }
                else {
                    System.out.print("\t" + asString(jMap.get(bin + "00")));
                    System.out.print("\t" + asString(jMap.get(bin + "01")));
                    System.out.print("\t" + asString(jMap.get(bin + "11")));
                    System.out.print("\t" + asString(jMap.get(bin + "10")));
                }

                System.out.println();
            }

            System.out.println("-------------------------------------");

            // draw K
            for (int i = 0; i < first; i++) {
                System.out.print(ABC.charAt(i));
            }
            System.out.print("\\");
            for (int i = first; i < max; i++) {
                System.out.print(ABC.charAt(i));
            }

            System.out.print("\t");

            if (second == 1)
                System.out.print("0\t1");
            else
                System.out.print("00\t01\t11\t10");

            System.out.println();

            for (int i = 0; i < Math.pow(2, first); i++) {
                String bin = toBinary(i, first);
                if (bin.equals("10"))
                    bin = "11";
                else if (bin.equals("11"))
                    bin = "10";

                System.out.print(bin + "|");
                if (second == 1) {
                    System.out.print("\t" + asString(kMap.get(bin + "0")));
                    System.out.print("\t" + asString(kMap.get(bin + "1")));
                }
                else {
                    System.out.print("\t" + asString(kMap.get(bin + "00")));
                    System.out.print("\t" + asString(kMap.get(bin + "01")));
                    System.out.print("\t" + asString(kMap.get(bin + "11")));
                    System.out.print("\t" + asString(kMap.get(bin + "10")));
                }

                System.out.println();
            }

            boolean or = false;

            System.out.print("J(" + ABC.charAt(i1) + "):");
            for (String key : jMap.keySet()) {
                if (jMap.get(key).equals("1")) {
                    int len = key.length();
                    key += "(";
                    for (int j1 = 0; j1 < len; j1++) {
                        key += (key.charAt(j1) == '1' ? "" : "�") + ABC.charAt(j1);
                    }
                    key += ")";
                    System.out.print((or ? " + " : "") + key);
                    or = true;
                }
            }
            System.out.println();

            or = false;

            System.out.print("K(" + ABC.charAt(i1) + "):");
            for (String key : kMap.keySet()) {
                if (kMap.get(key).equals("1")) {
                    int len = key.length();
                    key += "(";
                    for (int j1 = 0; j1 < len; j1++) {
                        key += (key.charAt(j1) == '1' ? "" : "�") + ABC.charAt(j1);
                    }
                    key += ")";
                    System.out.print((or ? " + " : "") + key);
                    or = true;
                }
            }
            System.out.println();
            System.out.println("-------------------------------------");
        }
    }   // draw KMap

    private void drawJ() {

    }

    private void drawK() {

    }

    private String asString(String s) {
        return s == null ? "-" : s;
    }

    private String toBinary(int value, int stringLength) {
        String res = Integer.toBinaryString(value);
        while (res.length() < stringLength) {
            res = "0" + res;
        }
        return res;
    }
}
