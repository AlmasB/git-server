counterlogic
============

binary counter logic generator
