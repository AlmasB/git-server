package com.almasb.vending

import javafx.beans.property.SimpleObjectProperty
import javafx.collections.FXCollections
import java.util.*

/**
 *
 *
 * @author Almas Baimagambetov (almaslvl@gmail.com)
 */
class Model {

    val items = FXCollections.observableArrayList<Item>()

    /**
     * Money available in the machine.
     */
    val machineMoney = SimpleObjectProperty<Money>(Money())

    /**
     * Stores temporary transaction money.
     */
    val userMoney = SimpleObjectProperty<Money>(Money())

    val selectedItem = SimpleObjectProperty<Item>()

    init {
        // machine setup
        val item1 = Item("Item1", Money(1, 20), 5)
        val item2 = Item("Item2", Money(0, 50), 5)
        val item3 = Item("Item3", Money(0, 95), 5)
        val item4 = Item("Item4", Money(0, 55), 5)
        val item5 = Item("Item5", Money(0, 35), 5)

        addItem(item1)
        addItem(item2)
        addItem(item3)
        addItem(item4)
        addItem(item5)

        // put 100 coins / bills of each available type
        MoneyType.values().forEach { machineMoney.get().add(it, 100) }
    }

    fun addItem(item: Item) {
        items.add(item)
    }

    fun insertMoney(type: MoneyType) {
        userMoney.get().add(type, 1)

        if (userMoney.get().value >= selectedItem.get().price.value) {
            buyItem(selectedItem.value)
        }
    }

    private fun buyItem(item: Item) {
        val change = userMoney.get().value - item.price.value

        if (change == 0) {
            giveItem(item)
            machineMoney.get().add(userMoney.get())
        } else {
            val money = Money.make(change)

            if (machineMoney.get().canMakeChangeFor(money)) {
                machineMoney.get().add(userMoney.get())
                item.take()
                giveItem(item)
                giveMoney(money)
            } else {
                println("Not enough change in the machine")
                cancel()
            }
        }
    }

    private fun giveItem(item: Item) {
        println("Giving item: ${item.name}")
    }

    private fun giveMoney(type: MoneyType, count: Int) {
        println("\tGiving: $count of $type")
    }

    private fun giveMoney(money: Money) {
        println("Giving change of: $money")

        val changeMap = money.counts
        for (type in changeMap.keys) {
            val count = changeMap[type]
            if (count!! > 0)
                giveMoney(type, count)
        }
    }

    fun cancel() {
        giveMoney(userMoney.get())
        userMoney.get().clear()
    }
}