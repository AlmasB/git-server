package com.almasb.vending

/**
 *
 *
 * @author Almas Baimagambetov (almaslvl@gmail.com)
 */
data class Item(val name: String, val price: Money, var count: Int) {

    fun refill(count: Int) {
        this.count += count
    }

    fun take() {
        if (!available())
            throw IllegalStateException("There are no more items")
        count--
    }

    fun available(): Boolean {
        return count > 0
    }

    override fun toString(): String {
        return "$name: $price"
    }
}