package com.almasb.vending

import javafx.application.Application
import javafx.fxml.FXMLLoader
import javafx.scene.Parent
import javafx.scene.Scene
import javafx.stage.Stage
import javafx.util.Callback

/**
 *
 *
 * @author Almas Baimagambetov (almaslvl@gmail.com)
 */
class VendingMachineApp : Application() {

    override fun start(stage: Stage) {
        val fxmlLoader = FXMLLoader(javaClass.getResource("ui.fxml"))
        fxmlLoader.controllerFactory = Callback { t -> Controller(Model()) }

        stage.setScene(Scene(fxmlLoader.load()))
        stage.show()
    }
}

fun main(args: Array<String>) {
    Application.launch(VendingMachineApp::class.java, *args)
}