package com.almasb.vending;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.stream.IntStream;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class Controller {

    @FXML
    private HBox itemRow1;
    @FXML
    private HBox itemRow2;
    @FXML
    private HBox itemRow3;

    @FXML
    private ChoiceBox<Item> cbItem;
    @FXML
    private ChoiceBox<MoneyType> cbMoneyType;

    @FXML
    private Label labelMessage;

    private Model model;

    public Controller(Model model) {
        this.model = model;
    }

    public void initialize() {
        cbItem.setItems(model.getItems());
        cbItem.valueProperty().bindBidirectional(model.getSelectedItem());
        cbItem.getSelectionModel().selectFirst();

        cbMoneyType.getItems().addAll(MoneyType.values());
        cbMoneyType.getSelectionModel().selectFirst();

//        // add items to UI
//        for (int i = 0; i < 5; i++) {
//            itemRow1.getChildren().add(new Circle(10));
//            itemRow2.getChildren().add(new Rectangle(20, 20));
//            itemRow3.getChildren().add(new Ellipse(10, 5));
//        }
    }

    public void onInsertMoney() {
        model.insertMoney(cbMoneyType.getValue());
    }

    public void onCancel() {
        model.cancel();
    }

//    @FXML
//    private void refillItem() {
//
//    }
//
//    public void buyItem(int row) {
//        try {
//            //super.buyItem(row);
//        }
//        catch (Exception e) {
//            handleError(e.getMessage());
//        }
//    }
//
//    protected void giveItem(int row) {
//        switch (row) {
//            case 1:
//                itemRow1.getChildren().remove(0);
//                break;
//            case 2:
//                itemRow2.getChildren().remove(0);
//                break;
//            case 3:
//                itemRow3.getChildren().remove(0);
//                break;
//        }
//
//        System.out.println("Giving item at row: " + row);
//    }
//
//    protected void giveMoney(MoneyType type, int count) {
//        System.out.println("Giving money: " + count + " of " + type.toString());
//    }
//
//    protected void handleError(String error) {
//        System.out.println("Error: " + error);
//    }
}
