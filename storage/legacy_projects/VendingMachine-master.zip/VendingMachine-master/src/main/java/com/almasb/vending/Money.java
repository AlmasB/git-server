package com.almasb.vending;

import java.util.HashMap;
import java.util.Map;

public class Money {

    private Map<MoneyType, Integer> money = new HashMap<MoneyType, Integer>();

    private int pounds;
    private int pence;

    public Money(int pounds, int pence) {
        this.pounds = pounds;
        this.pence = pence;
        for (MoneyType type : MoneyType.values())
            money.put(type, 0);
    }

    public Money() {
        this(0, 0);
    }

    public void clear() {
        for (MoneyType type : MoneyType.values())
            money.put(type, 0);
        pounds = 0;
        pence = 0;
    }

    public Map<MoneyType, Integer> getCounts() {
        return money;
    }

    public Money add(MoneyType type, int count) {
        money.put(type, money.get(type) + count);
        pence += type.value * count;
        return this;
    }

    public int getValue() {
        return pounds * 100 + pence;
    }

    /**
     * Adds 'other' money instance to this
     * Also clears the value of the 'other' instance
     *
     * @param other
     */
    public void add(Money other) {
        for (MoneyType type : other.money.keySet()) {
            money.put(type, money.get(type) + other.money.get(type));
        }

        other.clear();
    }

    public boolean canMakeChangeFor(Money other) {
        for (MoneyType type : other.money.keySet()) {
            if (other.money.get(type) > money.get(type)) {
                return false;
            }
        }

        return true;
    }

    public static Money make(int pence) {
        Money money = new Money();
        // we iterate in descending order of values
        for (int i = MoneyType.values().length - 1; i >= 0; i--) {
            MoneyType type = MoneyType.values()[i];
            if (pence >= type.value) {
                money.add(type, pence / type.value);
                pence = pence % type.value;
            }
        }

        return money;
    }

    @Override
    public String toString() {
        return "£" + pounds + "." + (pence < 9 ? "0" : "") + pence;
    }
}
