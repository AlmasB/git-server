package com.almasb.vending;

public enum MoneyType {
    ONE_PENNY   (1),
    FIVE_PENCE  (5),
    TWENTY_PENCE(20),
    FIFTY_PENCE (50),
    ONE_POUND   (100),
    FIVE_POUNDS (500),
    TEN_POUNDS  (1000);

    public final int value;

    private MoneyType(int value) {
        this.value = value;
    }
}
