## Vending Machine
One of the many possible solutions to the vending machine problem

Note: development in progress, there are still many bugs in back and front end

## Tutorial Specifications (Brief)
The vending machine has 5 rows of items that it sells.
Each row also contains 5 items of that type.
First the user selects the row of items he wants to buy.
The machine shows the price of an item in that row.
The user inserts coins (1p, 5p, 20p, 50p) or cash (£1, £5, £10).
Once there is enough money for the selected item, the machine no longer accepts any money.
The item is given to the user, along with change (highest value first), if any.
Alternatively, while money is inserted, the user can press "cancel", forcing the
machine to return inserted money (using highest value first).
Once the transaction is completed, one way or another, the button for selecting
item rows becomes available again.

## Extension
Add the admin panel to the machine, so that money can be withdrawn / inserted.
Items can be refilled. Price for items can be set.

## Notes
The solution to both the main part and the extension are available under "src/".
