$(main);    // entry point

/* CLASS DEFS */

$.Class.extend("GameObject", {
               
               }, {
               init: function(x, y, w, h, color) {
               this.x = x;
               this.y = y;
               this.w = w;
               this.h = h;
               this.color = color;
               this.speed = {x: 0, y: 0};
               },
               
               move: function() {
               this.x += this.speed.x;
               this.y += this.speed.y;
               },
               
               isColliding: function(obj2) {
               if (this.x > obj2.x + obj2.w || this.x + this.w < obj2.x
                   || this.y > obj2.y + obj2.h || this.y + this.h < obj2.y)
               return false;
               return true;
               }
               });

var W, H;
var MAX_BRICKS = 30;

var g;  // graphics context, dont want to be global tho, is there a way?
var bat, ball, bricks = [];
var score = 0;
var event = "NONE";

function main() {
    var canvas = document.getElementById("canvas");
    W = canvas.width;
    H = canvas.height;
    
    if (canvas.getContext) {
        g = canvas.getContext("2d");
        
        bat = new GameObject(W/2-60, H-15, 120, 15, "blue");
        ball = new GameObject(W/2, H/2, 30, 30, "red");
        
        ball.speed.x = 5;
        ball.speed.y = 5;
        
        for (var i = 0; i < MAX_BRICKS; i++)
            bricks[i] = new GameObject((i%10)*40, Math.floor(i/10)*20, 30, 15, "black");
        
        if (typeof gameLoop != "undefined")
            clearInterval(gameLoop);
        gameLoop = setInterval(loop, 60);
    }
}

function loop() {
    update();
    render();
}

function update() {
    ball.move();
    if (ball.x + ball.w >= W || ball.x <= 0) ball.speed.x *= -1;
    if (ball.y + ball.h >= H || ball.y <= 0) ball.speed.y *= -1;
    
    for (var i = 0; i < bricks.length; i++) {
        if (bricks[i] != null && ball.isColliding(bricks[i])) {
            bricks[i] = null;
            score += 200;
            ball.speed.y *= -1;
        }
    }
    
    if (ball.isColliding(bat)) {
        ball.speed.y *= -1;
    }
    
    if (event == "RIGHT")
        bat.speed.x = 10;
    else if (event == "LEFT")
        bat.speed.x = -10;
    
    bat.move();
    bat.speed.x = 0;
}

function render() {
    // draw background
    g.fillStyle = "white";
    g.fillRect(0, 0, W, H);
    
    for (var i = 0; i < bricks.length; i++)
        if (bricks[i] != null)
            draw(bricks[i]);
    
    draw(bat);
    draw(ball);
    
    renderUI();
}

function renderUI() {
    g.fillStyle = "blue";
    g.font = "30px Arial";
    var uiText = "Score: " + score;
    g.fillText(uiText, W - 300, 35);
}

function draw(object) {
    g.fillStyle = object.color;
    g.fillRect(object.x, object.y, object.w, object.h);
}

var KEY_LEFT = "37", KEY_RIGHT = "39", KEY_UP = "38", KEY_DOWN = "40";

// keylistener
$(document).keydown(function(e) {
                    var key = e.which;
                    if (key == KEY_LEFT)  event = "LEFT";
                    if (key == KEY_RIGHT) event = "RIGHT";
                    })

$(document).keyup(function(e) {
                    var key = e.which;
                    if (key == KEY_LEFT || key == KEY_RIGHT)  event = "NONE";
                    })