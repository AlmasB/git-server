Breakout3
=========

A game of breakout for 2 people to play over Internet or local network
Other players can join the existing game to spectate

The networking layer and server/client communication, as well as GUI are built on top
of the JavaFX demo samples by Oracle:
http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
