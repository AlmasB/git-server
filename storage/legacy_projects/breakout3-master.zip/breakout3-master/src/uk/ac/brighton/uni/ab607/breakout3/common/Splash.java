/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.common;

import uk.ac.brighton.uni.ab607.breakout3.R;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Parent;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.util.Duration;

public class Splash extends Parent {

    private ImageView background, imageBreak, imageOut, image3, pressanykey;
    private TranslateTransition imageOutTransition, imageBreakTransition, image3Transition;

    private final int CENTER_X, CENTER_Y;
    private GameMain game;

    public Splash(final GameMain game) {
        CENTER_X = Config.SCREEN_WIDTH / 2;
        CENTER_Y = Config.SCREEN_HEIGHT / 2;
        this.game = game;

        background = new ImageView();
        background.setFocusTraversable(true);
        background.setImage(R.getImage(R.drawablefx.background));
        background.setFitWidth(Config.SCREEN_WIDTH);
        background.setFitHeight(Config.SCREEN_HEIGHT);
        background.setOnMousePressed((MouseEvent me) -> {
            game.startGame();
        });
        background.setOnKeyPressed((KeyEvent ke) -> {
            game.startGame();
        });

        imageBreak = new ImageView();
        imageBreak.setImage(R.getImage(R.drawablefx.ui_break));
        imageBreak.setTranslateX(-imageBreak.getImage().getWidth() - 100);
        imageBreak.setTranslateY(CENTER_Y - imageBreak.getImage().getHeight());

        imageOut = new ImageView();
        imageOut.setImage(R.getImage(R.drawablefx.ui_out));
        imageOut.setTranslateX(Config.SCREEN_WIDTH + 100);
        imageOut.setTranslateY(CENTER_Y - imageOut.getImage().getHeight());

        image3 = new ImageView();
        image3.setImage(R.getImage(R.drawablefx.ui_3));
        image3.setTranslateX(CENTER_X + imageOut.getImage().getWidth());
        image3.setTranslateY(-100);

        pressanykey = new ImageView();
        pressanykey.setImage(R.getImage(R.drawablefx.ui_pressanykey));
        pressanykey.setTranslateX((Config.SCREEN_WIDTH - pressanykey.getImage().getWidth()) / 2);
        double y = imageOut.getTranslateY() + imageOut.getImage().getHeight();
        pressanykey.setTranslateY(y + (Config.SCREEN_HEIGHT - y) / 2);
        pressanykey.setOpacity(0);

        initAnimations();

        getChildren().addAll(background, imageBreak, imageOut, image3, pressanykey);
    }

    private void initAnimations() {
        imageOutTransition = new TranslateTransition(Duration.seconds(1), imageOut);
        imageOutTransition.setToX(CENTER_X - imageOut.getImage().getWidth() / 2);
        imageOutTransition.setOnFinished(event -> {
            imageBreakTransition = new TranslateTransition(Duration.seconds(1), imageBreak);
            imageBreakTransition.setToX(CENTER_X - imageBreak.getImage().getWidth());
            imageBreakTransition.play();
            imageBreakTransition.setOnFinished(event2 -> {
                imageOutTransition = new TranslateTransition(Duration.seconds(1), imageOut);
                imageOutTransition.setToX(CENTER_X);
                imageOutTransition.play();
                imageOutTransition.setOnFinished(event3 -> {
                    image3Transition = new TranslateTransition(Duration.seconds(1.5), image3);
                    image3Transition.setToY(CENTER_Y - image3.getImage().getHeight());
                    image3Transition.play();
                    image3Transition.setOnFinished(event4 -> {
                        FadeTransition ft = new FadeTransition(Duration.seconds(1), pressanykey);
                        ft.setToValue(1);
                        ft.setOnFinished(finalEvent -> {
                            if (GameMain.server)
                                game.startGame();
                        });
                        ft.play();
                    });
                });
            });
        });
    }

    public void start() {
        background.requestFocus();
        imageOutTransition.play();
    }

    public void stop() {
        imageOutTransition.stop();
    }
}
