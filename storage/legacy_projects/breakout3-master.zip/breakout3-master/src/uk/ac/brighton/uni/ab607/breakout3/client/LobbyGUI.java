/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.client;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListView;
import javafx.scene.control.TitledPane;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import com.almasb.java.ui.FXWindow;

/**
 * Lobby window
 *
 * This is the first window clients see
 * after successfully logging in
 *
 * From this window players can spectate other games
 * or play themselves. In either case once they have
 * chosen the option, the actual game window will
 * be shown while lobby window will be hidden
 *
 * @author Almas Baimagambetov (ab607@uni.brighton.ac.uk)
 * @version 1.0
 *
 */
public class LobbyGUI extends FXWindow implements View {

    private String playerName;
    private String action = "";

    private ObservableList<Text> games = FXCollections.observableArrayList();
    private ObservableList<Text> friends = FXCollections.observableArrayList();

    public LobbyGUI(String playerName, String ip) {
        this.playerName = playerName;
    }

    @Override
    protected void createContent(Pane root) {
        final ListView<Text> listView = new ListView<Text>();
        listView.setItems(games);
        listView.setMaxHeight(200);

        final ListView<Text> listView2 = new ListView<Text>();
        listView2.setItems(friends);
        listView2.setMaxHeight(200);

        final Button button = new Button("PLAY");
        button.setEffect(new Lighting(new Light.Distant(70, 70, Color.GREENYELLOW)));
        button.setFont(Font.font(Font.getDefault().getFamily(), 36));
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //button.setDisable(true);
                action = "PLAY," + playerName;
            }
        });
        button.setContentDisplay(ContentDisplay.RIGHT);
        button.setLayoutX(400);

        Button spectateButton = new Button("SPECTATE");
        spectateButton.setOnAction(event -> {
            int index = listView.getSelectionModel().getSelectedIndex();
            if (index >= 0 && index < listView.getItems().size()) {
                action = "SPECTATE," + listView.getItems().get(index).getText();
            }
        });
        spectateButton.setLayoutX(400);
        spectateButton.setLayoutY(200);
        // if nothing selected disable the spectate button otherwise enable
        spectateButton.setDisable(true);
        listView.getSelectionModel().selectedIndexProperty().addListener((obs, oldValue, newValue) -> {
            spectateButton.setDisable(newValue.intValue() == -1);
        });

        VBox vBox = new VBox();
        TitledPane t1 = new TitledPane("Games", listView);
        TitledPane t2 = new TitledPane("Friends", listView2);

        t1.expandedProperty().addListener((observable, oldValue, newValue) -> {
            listView2.setMaxHeight(newValue ? 200 : 400);
        });

        t2.expandedProperty().addListener((observable, oldValue, newValue) -> {
            listView.setMaxHeight(newValue ? 200 : 400);
        });

        vBox.getChildren().addAll(t1, t2);

        root.getChildren().addAll(vBox, spectateButton, button);
    }

    @Override
    protected void initScene(Scene scene) {
    }

    @Override
    public void initStage(Stage primaryStage) {
        primaryStage.setTitle("Breakout3 Lobby");
        primaryStage.setResizable(false);
        primaryStage.centerOnScreen();
        primaryStage.setOnCloseRequest(event -> {
            action = "EXIT";
        });
        primaryStage.show();
    }

    public void updateSessionNames(String[] names) {
        runOnUiThread(() -> {
            games.removeIf(name -> !contains(name.getText(), names));

            for (String name : names) {
                if (!gamesListContains(name)) {
                    games.add(new Text(name));
                }
            }
        });
    }

    private boolean gamesListContains(String name) {
        for (Text text : games)
            if (text.getText().equals(name))
                return true;
        return false;
    }

    private boolean contains(String element, String[] array) {
        for (String s : array)
            if (element.equals(s))
                return true;
        return false;
    }

    @Override
    public String getActionRequest() {
        String tmp = action;
        action = "";
        return tmp;
    }
}
