/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.client;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javafx.application.Platform;
import uk.ac.brighton.uni.ab607.breakout3.common.Config;
import uk.ac.brighton.uni.ab607.breakout3.common.GameMain;

import com.almasb.common.net.DataPacket;
import com.almasb.common.net.ServerPacketParser;
import com.almasb.common.net.UDPClient;
import com.almasb.common.util.Out;

/**
 * Client side "bridge" with two main responsibilities
 *
 * <ol>
 * <li> Out connection. Constantly loops to retrieve any pending actions/events from
 * client GUI and sends them to the server </li>
 *
 * <li> In connection. Constantly loops to parse any response from the server and
 * perform or schedule any required actions </li>
 * </ol>
 *
 * @author Almas Baimagambetov (ab607@uni.brighton.ac.uk)
 * @version 1.0
 *
 */
public class GameClient implements Runnable {

    private GameMain game;
    private LobbyGUI lobby;

    private View currentGUI;

    private UDPClient client;

    private String playerName;

    private ScheduledFuture<?> pollRequestTask;

    private boolean running = true;

    public GameClient(String playerName, String ip) throws IOException {
        this.playerName = playerName;
        lobby = new LobbyGUI(playerName, ip);
        lobby.init();

        client = new UDPClient(ip, Config.NETWORK_PORT, new ServerResponseParser());
        client.send(new DataPacket("CONNECT," + playerName));

        currentGUI = lobby;

        pollRequestTask = Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(this, 0, 20, TimeUnit.MILLISECONDS);

    }

    /**
     * Main listening loop for pending actions
     * from GUI
     */
    @Override
    public void run() {
        if (!running)
            return;

        /*        if (lobby.getStage() != null) {
            Out.d("lobby", lobby.getStage().isShowing() + "");
            Out.d("FX", Platform.isImplicitExit() + "");
        }*/

        try {
            String data = currentGUI.getActionRequest();
            if (!data.isEmpty()/* && !data.endsWith("NONE")*/) {
                if (data.startsWith("EXIT")) {
                    running = false;
                    exit();
                }
                else
                    client.send(new DataPacket(data));
            }
        }
        catch (IOException e) {
            Out.e("run", "error in main client loop", this, e);
        }
    }

    private void exit() throws IOException {
        pollRequestTask.cancel(false);
        client.close();
        System.exit(0);
    }

    private class ServerResponseParser extends ServerPacketParser {
        /**
         * This method will be called back by listening thread
         * in {@link uk.ac.brighton.uni.ab607.libs.net.UDPClient}
         * whenever it receives a valid response from the server
         */
        @Override
        public void parseServerPacket(DataPacket packet) {
            String data = packet.stringData;

            Out.d("serverPacket", data);

            // Game accepted, start game gui
            // we should get session id player1 player2
            if (data.equals("GAME_ACCEPTED")) {
                Out.d("serverPacket", "GAME_ACCEPTED");

                byte playerNumber = 0;
                if (packet.byteData.length > 0) {
                    playerNumber = packet.byteData[0];
                }

                game = new GameMain(playerName + playerNumber);
                currentGUI = game;
                lobby.setVisible(false);
                game.init();
            }

            // in game updates
            if (data.startsWith("GAME_UPDATE")) {
                data = data.replace("GAME_UPDATE", "");
                if (game != null) {
                    game.updateGUI(data);
                    Out.d("updateGUI", data);
                }
            }

            // in lobby updates
            if (packet.multipleObjectData instanceof String[]) {
                lobby.updateSessionNames((String[]) packet.multipleObjectData);
            }
        }
    }
}
