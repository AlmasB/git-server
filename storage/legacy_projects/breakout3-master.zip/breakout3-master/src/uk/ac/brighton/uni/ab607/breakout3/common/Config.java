/*
 * Copyright (c) 2013-2014 Almas Baimagambetov
 * (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.common;

public final class Config {

    /**
     * DataPacket is formatted as follows
     * stringData - actual data
     * byteData - Query/Response
     *
     * @author Almas Baimagambetov (ab607@uni.brighton.ac.uk)
     * @version 1.0
     *
     */
    public enum Query {
        LOGIN_CHECK, CONNECT, LOBBY_SPECTATE, LOBBY_PLAY, GAME_EVENT
    }

    public enum Response {
        LOGIN_OK, LOGIN_FAIL, GAME_START, LOBBY_UPDATE, GAME_UPDATE
    }

    public static final int NETWORK_PORT = 55555;

    /**
     * Screen constants
     */
    public static final int FIELD_BRICK_IN_ROW = 15;
    public static final int WINDOW_BORDER = 3;
    public static final int TITLE_BAR_HEIGHT = 19;
    public static final int SCREEN_WIDTH = 960;
    public static final int SCREEN_HEIGHT = 960;
    public static final int INFO_TEXT_SPACE = 10;

    /**
     * Gameplay constants
     */
    public static final float ANIMATION_TIME_SCALE = 0.5f;

    public static final int BRICK_WIDTH = 48;
    public static final int BRICK_HEIGHT = 24;
    public static final int SHADOW_WIDTH = 10;
    public static final int SHADOW_HEIGHT = 16;

    public static final int BALL_MIN_SPEED = 3;
    public static final int BALL_MAX_SPEED = BRICK_HEIGHT;
    public static final int BALL_MIN_COORD_SPEED = 2;
    public static final float BALL_SPEED_INC = 0.1f;

    public static final int BAT_Y = SCREEN_HEIGHT - 40;
    public static final int BAT_SPEED = 8;

    public static final int BONUS_SPEED = 3;

    public static final int FIELD_WIDTH = FIELD_BRICK_IN_ROW * BRICK_WIDTH;
    public static final int FIELD_HEIGHT = FIELD_WIDTH;
    public static final int FIELD_Y = SCREEN_HEIGHT - FIELD_HEIGHT;

    public static final int LIVES_DEFAULT = 3;
    public static final int LIVES_MAX = 9;

    private Config() {}
}
