/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.common;

import uk.ac.brighton.uni.ab607.breakout3.R;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class GameObjects {

    public static class Ball extends Parent {

        public static final int DEFAULT_SIZE = 2;

        public static final int MAX_SIZE = 5;

        private int size;

        private int diameter;
        private ImageView imageView;

        public Ball() {
            imageView = new ImageView();
            getChildren().add(imageView);
            changeSize(DEFAULT_SIZE);
            setMouseTransparent(true);
        }

        public int getSize() {
            return size;
        }

        public int getDiameter() {
            return diameter;
        }

        public void changeSize(int newSize) {
            size = newSize;
            String id;
            switch (size) {
                case 1:
                    id = R.drawablefx.ball1;
                    break;
                case 2:
                    id = R.drawablefx.ball2;
                    break;
                case 3:
                    id = R.drawablefx.ball3;
                    break;
                case 4:
                    id = R.drawablefx.ball4;
                    break;
                case 5:
                    id = R.drawablefx.ball5;
                    break;
                default:
                    id = R.drawablefx.ball0;
                    break;
            }

            imageView.setImage(R.getImage(id));
            diameter = (int) imageView.getImage().getWidth() - Config.SHADOW_WIDTH;
        }
    }

    public static class Bat extends Parent {

        public static final int DEFAULT_SIZE = 2;

        public static final int MAX_SIZE = 7;

        private static final Image LEFT = R.getImage(R.drawablefx.bat_left);
        private static final Image CENTER = R.getImage(R.drawablefx.bat_center);
        private static final Image RIGHT = R.getImage(R.drawablefx.bat_right);

        private int size;
        private int width;
        private int height;

        private ImageView leftImageView;
        private ImageView centerImageView;
        private ImageView rightImageView;

        public int getSize() {
            return size;
        }

        public int getWidth() {
            return width;
        }

        public int getHeight() {
            return height;
        }

        public void changeSize(int newSize) {
            this.size = newSize;
            width = size * 12 + 45;
            double rightWidth = RIGHT.getWidth() - Config.SHADOW_WIDTH;
            double centerWidth = width - LEFT.getWidth() - rightWidth;
            centerImageView.setViewport(new Rectangle2D(
                    (CENTER.getWidth() - centerWidth) / 2, 0, centerWidth, CENTER
                    .getHeight()));
            rightImageView.setTranslateX(width - rightWidth);
        }

        public Bat() {
            height = (int) CENTER.getHeight() - Config.SHADOW_HEIGHT;
            Group group = new Group();
            leftImageView = new ImageView();
            leftImageView.setImage(LEFT);
            centerImageView = new ImageView();
            centerImageView.setImage(CENTER);
            centerImageView.setTranslateX(LEFT.getWidth());
            rightImageView = new ImageView();
            rightImageView.setImage(RIGHT);
            changeSize(DEFAULT_SIZE);
            group.getChildren().addAll(leftImageView, centerImageView,
                    rightImageView);
            getChildren().add(group);
            setMouseTransparent(true);
        }
    }

    public static class Bonus extends Parent {

        public static final int TYPE_SLOW = 0;
        public static final int TYPE_FAST = 1;
        public static final int TYPE_CATCH = 2;
        public static final int TYPE_GROW_BAT = 3;
        public static final int TYPE_REDUCE_BAT = 4;
        public static final int TYPE_GROW_BALL = 5;
        public static final int TYPE_REDUCE_BALL = 6;
        public static final int TYPE_STRIKE = 7;
        public static final int TYPE_LIFE = 8;

        public static final int COUNT = 9;

        public static final String[] NAMES = new String[] { "SLOW", "FAST",
            "CATCH", "GROW BAT", "REDUCE BAT", "GROW BALL", "REDUCE BALL",
            "STRIKE", "LIFE", };

        private int type;
        private int width;
        private int height;
        private ImageView content;

        public int getHeight() {
            return height;
        }

        public int getWidth() {
            return width;
        }

        public int getType() {
            return type;
        }

        public Bonus(int type) {
            content = new ImageView();
            getChildren().add(content);
            this.type = type;

            String id;
            switch (type) {
                case TYPE_SLOW:
                    id = R.drawablefx.bonus_slow;
                    break;
                case TYPE_FAST:
                    id = R.drawablefx.bonus_fast;
                    break;
                case TYPE_CATCH:
                    id = R.drawablefx.bonus_catch;
                    break;
                case TYPE_GROW_BAT:
                    id = R.drawablefx.bonus_bat_grow;
                    break;
                case TYPE_REDUCE_BAT:
                    id = R.drawablefx.bonus_bat_shrink;
                    break;
                case TYPE_GROW_BALL:
                    id = R.drawablefx.bonus_ball_grow;
                    break;
                case TYPE_REDUCE_BALL:
                    id = R.drawablefx.bonus_ball_shrink;
                    break;
                case TYPE_STRIKE:
                    id = R.drawablefx.bonus_strike;
                    break;
                case TYPE_LIFE: // fallthru
                default:
                    id = R.drawablefx.bonus_life;
                    break;
            }

            Image image = R.getImage(id);
            width = (int) image.getWidth() - Config.SHADOW_WIDTH;
            height = (int) image.getHeight() - Config.SHADOW_HEIGHT;
            content.setImage(image);
            setMouseTransparent(true);
        }
    }

    public static class Brick extends Parent {

        public static final int TYPE_BLUE = 0;
        public static final int TYPE_BROKEN1 = 1;
        public static final int TYPE_BROKEN2 = 2;
        public static final int TYPE_BROWN = 3;
        public static final int TYPE_CYAN = 4;
        public static final int TYPE_GREEN = 5;
        public static final int TYPE_GREY = 6;
        public static final int TYPE_MAGENTA = 7;
        public static final int TYPE_ORANGE = 8;
        public static final int TYPE_RED = 9;
        public static final int TYPE_VIOLET = 10;
        public static final int TYPE_WHITE = 11;
        public static final int TYPE_YELLOW = 12;

        private int type;
        private ImageView content;

        public Brick(int type) {
            content = new ImageView();
            getChildren().add(content);
            changeType(type);
            setMouseTransparent(true);
        }

        public int getType() {
            return type;
        }

        public boolean kick() {
            if (type == TYPE_GREY) {
                return false;
            }
            if (type == TYPE_BROKEN1) {
                changeType(TYPE_BROKEN2);
                return false;
            }
            return true;
        }

        private void changeType(int newType) {
            this.type = newType;
            String id;
            switch (type) {
                case TYPE_BLUE:
                    id = R.drawablefx.brick_blue;
                    break;
                case TYPE_BROKEN1:
                    id = R.drawablefx.brick_broken1;
                    break;
                case TYPE_BROKEN2:
                    id = R.drawablefx.brick_broken2;
                    break;
                case TYPE_BROWN:
                    id = R.drawablefx.brick_brown;
                    break;
                case TYPE_CYAN:
                    id = R.drawablefx.brick_cyan;
                    break;
                case TYPE_GREEN:
                    id = R.drawablefx.brick_green;
                    break;
                case TYPE_GREY:
                    id = R.drawablefx.brick_grey;
                    break;
                case TYPE_MAGENTA:
                    id = R.drawablefx.brick_magenta;
                    break;
                case TYPE_ORANGE:
                    id = R.drawablefx.brick_orange;
                    break;
                case TYPE_RED:
                    id = R.drawablefx.brick_red;
                    break;
                case TYPE_VIOLET:
                    id = R.drawablefx.brick_violet;
                    break;
                case TYPE_YELLOW:
                    id = R.drawablefx.brick_yellow;
                    break;
                case TYPE_WHITE:    // fallthru
                default:
                    id = R.drawablefx.brick_white;
                    break;
            }

            Image image = R.getImage(id);
            content.setImage(image);
            content.setFitWidth(Config.FIELD_WIDTH / 15);
        }

        public static int getBrickType(String s) {
            if (s.equals("L")) {
                return TYPE_BLUE;
            }
            else if (s.equals("2")) {
                return TYPE_BROKEN1;
            }
            else if (s.equals("B")) {
                return TYPE_BROWN;
            }
            else if (s.equals("C")) {
                return TYPE_CYAN;
            }
            else if (s.equals("G")) {
                return TYPE_GREEN;
            }
            else if (s.equals("0")) {
                return TYPE_GREY;
            }
            else if (s.equals("M")) {
                return TYPE_MAGENTA;
            }
            else if (s.equals("O")) {
                return TYPE_ORANGE;
            }
            else if (s.equals("R")) {
                return TYPE_RED;
            }
            else if (s.equals("V")) {
                return TYPE_VIOLET;
            }
            else if (s.equals("W")) {
                return TYPE_WHITE;
            }
            else if (s.equals("Y")) {
                return TYPE_YELLOW;
            }
            else {
                System.out.println("Unknown brick type '{s}'");
                return TYPE_WHITE;
            }
        }
    }
}
