/*
 * Copyright c) 2013-2014 Almas Baimagambetov a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;

import javafx.scene.image.Image;

import com.almasb.common.util.Out;
import com.almasb.java.io.ResourceManager;

public final class R {

    private static final HashMap<String, Image> images = new HashMap<String, Image>();

    public static Image getImage(String id) {
        return images.get(id);
    }

    public static final class drawable {

    }

    public static final class drawablefx {
        public static final String background = "images/desktop/background.png";
        public static final String bat_left = "images/desktop/bat/left.png";
        public static final String bat_center = "images/desktop/bat/center.png";
        public static final String bat_right = "images/desktop/bat/right.png";
        public static final String ball0 = "images/desktop/ball/ball0.png";
        public static final String ball1 = "images/desktop/ball/ball1.png";
        public static final String ball2 = "images/desktop/ball/ball2.png";
        public static final String ball3 = "images/desktop/ball/ball3.png";
        public static final String ball4 = "images/desktop/ball/ball4.png";
        public static final String ball5 = "images/desktop/ball/ball5.png";

        public static final String ui_logo = "images/desktop/logo.png";
        public static final String ui_break = "images/splash/break.png";
        public static final String ui_out = "images/splash/out.png";
        public static final String ui_3 = "images/splash/3.png";
        public static final String ui_brick_shadow = "images/desktop/splash/brickshadow.png";
        public static final String ui_breaker_shadow = "images/desktop/splash/breakershadow.png";
        public static final String ui_pressanykey = "images/desktop/splash/pressanykey.png";
        public static final String ui_pressanykey_shadow = "images/desktop/splash/pressanykeyshadow.png";
        public static final String ui_strike_shadow = "images/desktop/splash/strikeshadow.png";
        public static final String ui_sun = "images/desktop/splash/sun.png";
        public static final String ui_ready = "images/desktop/ready.png";
        public static final String ui_gameover = "images/desktop/gameover.png";

        public static final String brick_blue = "images/desktop/brick/blue.png";
        public static final String brick_broken1 = "images/desktop/brick/broken1.png";
        public static final String brick_broken2 = "images/desktop/brick/broken2.png";
        public static final String brick_brown = "images/desktop/brick/brown.png";
        public static final String brick_cyan = "images/desktop/brick/cyan.png";
        public static final String brick_green = "images/desktop/brick/green.png";
        public static final String brick_grey = "images/desktop/brick/grey.png";
        public static final String brick_magenta = "images/desktop/brick/magenta.png";
        public static final String brick_orange = "images/desktop/brick/orange.png";
        public static final String brick_red = "images/desktop/brick/red.png";
        public static final String brick_violet = "images/desktop/brick/violet.png";
        public static final String brick_white = "images/desktop/brick/white.png";
        public static final String brick_yellow = "images/desktop/brick/yellow.png";

        public static final String bonus_slow = "images/desktop/bonus/ballslow.png";
        public static final String bonus_fast = "images/desktop/bonus/ballfast.png";
        public static final String bonus_catch = "images/desktop/bonus/catch.png";
        public static final String bonus_bat_grow = "images/desktop/bonus/batgrow.png";
        public static final String bonus_bat_shrink = "images/desktop/bonus/batreduce.png";
        public static final String bonus_ball_grow = "images/desktop/bonus/ballgrow.png";
        public static final String bonus_ball_shrink = "images/desktop/bonus/ballreduce.png";
        public static final String bonus_strike = "images/desktop/bonus/strike.png";
        public static final String bonus_life = "images/desktop/bonus/extralife.png";
    }

    public static final class raw {
        public static final int hit = 0;
    }

    static {
        Field[] fields = R.drawablefx.class.getDeclaredFields();

        for (Field field : fields) {
            try {
                String id = (String) field.get(null);
                images.put(id, ResourceManager.loadFXImage(id));
            }
            catch (IllegalArgumentException | IllegalAccessException | IOException e) {
                Out.e(e);
            }

        }
    }
}
