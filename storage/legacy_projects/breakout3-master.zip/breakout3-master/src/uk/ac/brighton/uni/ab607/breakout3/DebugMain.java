package uk.ac.brighton.uni.ab607.breakout3;

import uk.ac.brighton.uni.ab607.breakout3.common.GameMain;

public class DebugMain {
    public static void main(String[] args) throws Exception {
        new GameMain("").init();
    }
}
