/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import uk.ac.brighton.uni.ab607.breakout3.client.View;

import com.almasb.common.net.DataPacket;
import com.almasb.common.net.UDPServer;
import com.almasb.common.util.Out;
import com.almasb.java.ui.FXWindow;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class GameMain extends FXWindow implements View {

    public enum UserAction {
        NONE, LEFT, RIGHT
    }

    public static String name = "";
    public static UserAction action = UserAction.NONE;
    public static boolean server = true;
    public static String dataIN = "";
    public static String dataOUT = "";

    public static Player player1, player2;

    //private Map<String, Integer> clientData = Collections.synchronizedMap(new HashMap<String, Integer>());
    private List<Player> clients = Collections.synchronizedList(new ArrayList<Player>());
    public String sessionName = "";
    public int id = 1;

    /**
     * Splash screen
     */
    private Splash splash;

    /**
     * Current level
     */
    private Level level;

    /**
     * Number of lives
     */
    private int lifeCount;

    /**
     * TODO: add score for 2nd player
     * Current score
     */
    private int score;

    /**
     * Current state
     * 0   - splash screen
     * 1.. - levels
     */
    private int state = 0;

    @Override
    public String getActionRequest() {  // GAME_UPDATE
        return "S1," + name.substring(0, name.length()-1) + "," + action.toString();
    }

    public GameMain(Player p1, Player p2) {
        player1 = p1;
        player2 = p2;
        //clientData.put(player1.ip, player1.getPort());
        //clientData.put(player2.ip, player2.getPort());
        clients.add(p1);
        clients.add(p2);
        sessionName = "S" + "1" + " - " + p1.name + " [VS] " + p2.name;
        changeState(0);
    }

    public GameMain(String player) {
        name = player;
        server = false;
        changeState(0);
    }

    public String getName() {
        return sessionName;
    }

    public String getID() {
        return "S" + id;
    }
    public void updateGUI(String d) {
        dataIN = d;
    }

    public void sendUpdates(UDPServer server) {
        DataPacket packet = new DataPacket(dataOUT);
        //Set<String> keys = clientData.keySet();


        synchronized (clients) {
            Iterator<Player> it = clients.iterator();
            while (it.hasNext()) {
                Player p = it.next();
                String ip = p.ip;
                int port = p.getPort();

                try {
                    server.send(packet, ip, port);
                }
                catch (IOException e) {
                    Out.e("sendUpdates", "Failed to send update data to client: "
                            + ip + ":" + port, this, e);
                }
            }
        }
    }

    @Override
    protected void createContent(Pane root) {
    }

    @Override
    protected void initScene(Scene scene) {}

    @Override
    public void initStage(Stage primaryStage) {
        primaryStage.setOnCloseRequest(event -> {
            System.exit(0);
        });
        primaryStage.setWidth(Config.SCREEN_WIDTH);
        primaryStage.setHeight(Config.SCREEN_HEIGHT);
        primaryStage.setResizable(false);

        if (!server)
            primaryStage.show();
    }

    public void addClient(Player p) {
        clients.add(p);
    }

    public void processUserAction(String name, String action) {
        if (level != null)
            level.processUserAction(name, action);
    }

    public int getState() {
        return state;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getLifeCount() {
        return lifeCount;
    }

    public void increaseLives() {
        lifeCount = Math.min(lifeCount + 1, Config.LIVES_MAX);
    }

    public void decreaseLives() {
        lifeCount--;
    }

    // Initializes game (lives, score etc)
    public void startGame() {
        lifeCount = Config.LIVES_DEFAULT;
        score = 0;
        // level 1
        changeState(1);
    }

    public void endGame() {
        if (splash != null) {
            splash.stop();
        }
        if (level != null) {
            level.stop();
        }
    }

    public void restartGame() {
        if (splash != null) {
            splash.start();
        }
        if (level != null) {
            level.restart();
        }
    }

    public void changeState(int newState) {
        this.state = newState;
        if (splash != null) {
            splash.stop();
        }
        if (level != null) {
            level.stop();
        }

        // game started or game has gone beyond number of levels
        if (state < 1 || state > LevelData.getLevelsCount()) {
            root.getChildren().remove(level);
            level = null;
            splash = new Splash(this);
            root.getChildren().add(splash);
            splash.start();
        }
        else {
            root.getChildren().remove(splash);
            splash = null;
            level = new Level(this, state);
            root.getChildren().add(level);
            level.start();
        }
    }
}
