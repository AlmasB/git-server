/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.client;

import java.awt.Toolkit;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javafx.animation.PathTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.effect.Lighting;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextBoundsType;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import uk.ac.brighton.uni.ab607.breakout3.R;
import uk.ac.brighton.uni.ab607.breakout3.common.Config;

import com.almasb.common.net.DataPacket;
import com.almasb.common.net.DataPacketParser;
import com.almasb.common.net.UDPClient;
import com.almasb.common.util.Out;
import com.almasb.java.audio.JavaAudioPlayer;
import com.almasb.java.ui.FXWindow;

/**
 * The login window for client
 *
 * @author Almas Baimagambetov (ab607@uni.brighton.ac.uk)
 * @version 1.0
 *
 */
public class LoginGUI extends FXWindow {

    /**
     * The path transition used for moving the ball
     * across the screen
     */
    private PathTransition pathTransition;

    /**
     * Width and Height of the display (NOT window)
     */
    private int W, H;

    /**
     * The pre-game client used to test connection
     * to server
     */
    private UDPClient client;

    /**
     * Parser for recv data
     */
    private LoginDataParser loginParser = new LoginDataParser();

    /**
     * Background thread used for connection, so that JavaFX UI thread
     * keeps being responsive
     */
    private ExecutorService workerThread = Executors.newSingleThreadExecutor();

    /**
     * Connection timeout thread, so that we don't wait too long for
     * failed connection
     */
    private ExecutorService timeoutThread = Executors.newSingleThreadExecutor();

    /**
     * Username and ip will store valid data
     * once this window is closed
     *
     * If connection failed, both will be empty strings
     */
    public String username = "", ip = "";

    private JavaAudioPlayer audioPlayer = new JavaAudioPlayer();

    @Override
    public void initStage(Stage primaryStage) {
        W = Toolkit.getDefaultToolkit().getScreenSize().width;
        H = Toolkit.getDefaultToolkit().getScreenSize().height;


        primaryStage.initStyle(StageStyle.TRANSPARENT);

        Group root = new Group();
        Scene scene = new Scene(root, W, H, Color.TRANSPARENT);
        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();

        Circle ball = new Circle(120, 120, 120);
        ball.setFill(new RadialGradient(-0.3, 135, 0.5, 0.5, 1,
                true, CycleMethod.NO_CYCLE, new Stop[] {
                new Stop(0, Color.DARKGRAY),
                new Stop(1, Color.BLACK) }));

        final TextField name = new TextField();
        name.setPromptText("username");
        name.setFont(Font.font(Font.getDefault().getFamily(), 14));

        final TextField serverIP = new TextField();
        serverIP.setPromptText("server ip");
        serverIP.setText("127.0.0.1");
        serverIP.setFont(Font.font(Font.getDefault().getFamily(), 14));

        // Logo
        final Text text = new Text("Breakout3");
        text.setFill(Color.WHITESMOKE);
        text.setEffect(new Lighting());
        text.setBoundsType(TextBoundsType.VISUAL);
        text.setFont(Font.font(Font.getDefault().getFamily(), 30));

        Button login = new Button("Login");
        login.setOnAction(event -> {
            login.setDisable(true);

            final CountDownLatch ready = new CountDownLatch(1);
            final Future<?> loginTask = workerThread.submit(() -> {
                try {
                    client = new UDPClient(serverIP.getText(), Config.NETWORK_PORT, loginParser);
                    if (client == null)
                        return;

                    while (!client.isConnected()) {
                        Thread.sleep(5);
                    }

                    client.send(new DataPacket("CHECK_PLAYER", name.getText().getBytes()));

                    while (!loginParser.playerAccepted)
                        Thread.sleep(5);

                    ready.countDown();
                }
                catch (Exception e) {
                    Out.e("loginTask", "Failed to login", this, e);
                }
            });

            timeoutThread.execute(() -> {
                boolean timeout = false;;
                try {
                    timeout = !ready.await(2, TimeUnit.SECONDS);
                }
                catch (Exception e) {
                    Out.e("Timeout", "Unexpected interrupt", this, e);
                }

                if (timeout) {
                    loginTask.cancel(true);
                    Platform.runLater(() -> login.setDisable(false));
                }
                else {
                    username = name.getText();
                    ip = serverIP.getText();
                    Out.i("login", "sucessful");
                    setVisible(false);

                    try {
                        new GameClient(username, ip);
                    }
                    catch (Exception e) {
                        Out.e("Login", "Failed to start game client", this, e);
                        System.exit(0);
                    }
                }
            });
        });

        // create button for closing application
        Button close = new Button("Exit");
        close.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
                System.exit(0);
            }
        });

        // vertical layout
        VBox vBox = new VBox();
        vBox.setSpacing(10);
        vBox.setPadding(new Insets(60, 0, 0, 35));
        vBox.setAlignment(Pos.CENTER);

        // horizontal layout for buttons
        HBox hBox = new HBox();
        hBox.setSpacing(20);
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().addAll(login, close);

        vBox.getChildren().addAll(text, name, serverIP, hBox);
        vBox.setVisible(false);

        // add all nodes to main root group
        root.getChildren().addAll(ball, vBox);

        Path path = new Path();
        path.getElements().addAll(
                // move the ball window here
                new MoveTo(120,120),
                // draw paths to bounce
                new LineTo(W / 2, H - 120),
                new LineTo(W - 120, 120),
                new LineTo(120, H - 120),
                new LineTo(W / 2, 120),
                new LineTo(W / 2, H / 2));

        ScheduledFuture<?> sound = Executors.newSingleThreadScheduledExecutor().scheduleAtFixedRate(() -> {
            audioPlayer.playSound(R.raw.hit);
        }, 550, 600, TimeUnit.MILLISECONDS);

        pathTransition = new PathTransition(Duration.seconds(2.5), path, root);
        pathTransition.setOnFinished(event -> {
            vBox.setVisible(true);
            sound.cancel(true);
            // so that text fields can show prompt text
            login.requestFocus();
        });

        primaryStage.show();
        pathTransition.play();
    }

    private class LoginDataParser implements DataPacketParser {
        boolean playerAccepted = false;

        @Override
        public void parseClientPacket(DataPacket arg0) {}

        @Override
        public void parseServerPacket(DataPacket packet) {
            if (packet.stringData.equals("CHECK_PLAYER_GOOD")) {
                playerAccepted = true;
            }
        }
    }

    @Override
    protected void createContent(Pane root) {
        // TODO Auto-generated method stub

    }

    @Override
    protected void initScene(Scene scene) {
        // TODO Auto-generated method stub

    }
}
