/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3;

import uk.ac.brighton.uni.ab607.breakout3.client.LoginGUI;
import uk.ac.brighton.uni.ab607.breakout3.server.GameServer;

import com.almasb.common.util.Out;
import com.almasb.java.io.Resources;

/**
 * Breakout3 Main class
 *
 * @author Almas Baimagambetov (ab607@uni.brighton.ac.uk)
 * @version 1.0
 *
 */
public class Main {

    /**
     * Displays info about accepted application
     * arguments
     */
    private static void usage() {
        Out.println("Usage:");
        Out.println("java -jar breakout3_X.jar -option");
        Out.println("where X is the version");
        Out.println("Options:\t Description:");
        Out.println("-? -help -usage\t prints this info message");
        Out.println("-local \t\t starts the server and locally connects to it (Debug)");
        Out.println("-server\t\t starts headless server");
        Out.println("-client\t\t starts the client");
    }

    /**
     * Main entry point to Breakout3
     *
     * @param args - one of the predefined commands
     *              to alter the behaviour of the application
     *              "-help" will print more details
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            usage();
            return;
        }

        boolean server = false, client = false;

        switch (args[0]) {
            case "-local":
                server = true;
                client = true;
                break;
            case "-server":
                server = true;
                break;
            case "-client":
                client = true;
                break;

            case "-?": case "-help": case "-usage": // fallthru
            default:
                usage();
                return;
        }

        Resources.init(R.drawable.class, R.raw.class);

        try {
            if (server)
                new GameServer();

            if (client) {
                new LoginGUI().init();
            }
        }
        catch (Exception e) {
            Out.e(e);
            Out.println("Application will now close");
        }
    }
}
