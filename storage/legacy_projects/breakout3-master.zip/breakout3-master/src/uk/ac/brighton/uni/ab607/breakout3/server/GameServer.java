/*
 * Copyright (c) 2013-2014 Almas Baimagambetov (a.baimagambetov1@uni.brighton.ac.uk)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package uk.ac.brighton.uni.ab607.breakout3.server;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import uk.ac.brighton.uni.ab607.breakout3.common.Config;
import uk.ac.brighton.uni.ab607.breakout3.common.GameMain;
import uk.ac.brighton.uni.ab607.breakout3.common.Player;

import com.almasb.common.net.ClientPacketParser;
import com.almasb.common.net.DataPacket;
import com.almasb.common.net.UDPServer;
import com.almasb.common.util.Out;

public class GameServer implements Runnable {

    private UDPServer server;
    private boolean running = true;


    private ArrayList<Player> players = new ArrayList<Player>();
    private ArrayList<GameMain> sessions = new ArrayList<GameMain>();

    // TODO: change to a proper queue for better efficiency
    private ArrayList<Player> matchMakingQueue = new ArrayList<Player>();

    private ScheduledFuture<?> serverLoopTask;

    public GameServer() throws SocketException {
        server = new UDPServer(Config.NETWORK_PORT, new ClientQueryParser());
        serverLoopTask = new ScheduledThreadPoolExecutor(1).scheduleAtFixedRate(this, 0, 20, TimeUnit.MILLISECONDS);
    }

    @Override
    public void run() {
        try {
            // check if queue contains a pair for game
            if (matchMakingQueue.size() > 1) {
                Player pl1 = matchMakingQueue.remove(0);
                Player pl2 = matchMakingQueue.remove(0);

                sessions.add(new GameMain(pl1, pl2));

                // send to each player that game started
                server.send(new DataPacket("GAME_ACCEPTED", new byte[] {1}), pl1.ip, pl1.getPort());
                server.send(new DataPacket("GAME_ACCEPTED", new byte[] {2}), pl2.ip, pl2.getPort());
            }

            // collect session names and send them if there's at least 1
            String[] sessionNames = sessions.stream().map(session -> {
                // doing update here saves from too much iteration
                session.sendUpdates(server);
                return session.getName();
            }).toArray(String[]::new);

            if (sessionNames.length > 0) {
                for (Player p : players) {
                    server.send(new DataPacket(sessionNames), p.ip, p.getPort());
                }
            }
        }
        catch (Exception e) {
            Out.e("run", "Error in main server loop", this, e);
        }
    }

    class ClientQueryParser extends ClientPacketParser {
        @Override
        public void parseClientPacket(DataPacket packet) {
            // this is where client action requests arrive
            String data = packet.stringData;
            if (data.startsWith("CONNECT")) {
                String name = data.replace("CONNECT,", "");
                players.add(new Player(name, packet.getIP(), packet.getPort()));
                Out.d("parseClientPacket", "player " + name + " connected. IP: " + packet.getIP() + " Port: " + packet.getPort());
            }

            // the format could be "S1,playerName,RIGHT"
            // find which session and send
            if (data.startsWith("S")) {
                String id = data.split(",")[0]; // exception check needed
                GameMain s = getGameModelByID(id);
                if (s != null) {
                    Out.d("processUserAction", data);
                    s.processUserAction(data.split(",")[1], data.split(",")[2]);
                }
            }

            if (data.startsWith("CHECK_PLAYER")) {
                String name = new String(packet.byteData);
                // do checking

                try {
                    server.send(new DataPacket("CHECK_PLAYER_GOOD"), packet.getIP(), packet.getPort());
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (data.startsWith("PLAY")) {
                // put into matchmaking queue
                String name = data.replace("PLAY,", "");
                matchMakingQueue.add(new Player(name, packet.getIP(), packet.getPort()));
                Out.d("", "Added to matchmaking queue: " + name);
                Out.d("", "Queue size: " + matchMakingQueue.size());
            }

            if (data.startsWith("SPECTATE")) {
                try {
                    // to inform client to run the game
                    server.send(new DataPacket("GAME_ACCEPTED"), packet.getIP(), packet.getPort());
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                data = data.replace("SPECTATE,", "");
                // data is now session name
                GameMain s = getGameModelByName(data);
                s.addClient(new Player("", packet.getIP(), packet.getPort()));
                //s.addClient(packet.getIP(), packet.getPort());
            }
        }
    }

    private GameMain getGameModelByID(String id) {
        return sessions.stream().filter(session -> session.getID().equals(id)).findFirst().orElse(null);
    }

    private GameMain getGameModelByName(String name) {
        return sessions.stream().filter(session -> session.getName().equals(name)).findFirst().orElse(null);
    }
}
