diabolo-haskell
===============

solution to diabolo in haskell
