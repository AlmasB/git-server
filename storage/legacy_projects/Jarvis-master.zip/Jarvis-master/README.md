# Jarvis
Java Airline Reservation Virtual Interactive System (JARVIS)

# Design
The design is kept very simple. Only 1 time per day per flight. Only 1 flight from X to Y.