package com.almasb.jarvis.common.api;

public interface Response {

}
