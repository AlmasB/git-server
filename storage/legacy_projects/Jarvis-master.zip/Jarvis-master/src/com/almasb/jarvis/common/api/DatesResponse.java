package com.almasb.jarvis.common.api;

import com.almasb.jarvis.common.datetime.Date;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DatesResponse implements Response {

    private final Date[] dates;

    @JsonCreator
    public DatesResponse(@JsonProperty("dates") Date[] dates) {
        this.dates = dates;
    }

    public Date[] getDates() {
        return dates;
    }
}
