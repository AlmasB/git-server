package com.almasb.jarvis.common.domain;

import java.util.HashMap;
import java.util.Map;

import com.almasb.jarvis.common.datetime.Time;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties({"daysTimes"})
public class FlightInfo implements Comparable<FlightInfo> {

    private final String code;
    private final String source;
    private final String destination;

    /**
     * 1 - Monday
     * 7 - Sunday
     */
    private final Map<Integer, Time> daysTimes = new HashMap<>();

    @JsonCreator
    public FlightInfo(@JsonProperty("code") String code,
            @JsonProperty("source") String source,
            @JsonProperty("destination") String destination) {
        this.code = code;
        this.source = source;
        this.destination = destination;
    }

    public FlightInfo addDaysTimes(int day, Time time) {
        daysTimes.put(day, time);
        return this;
    }

    public String getCode() {
        return code;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public boolean isSameRoute(String source, String destination) {
        return this.source.equals(source) && this.destination.equals(destination);
    }

    public Integer[] getDays() {
        return daysTimes.keySet().toArray(new Integer[0]);
    }

    public Time getTime(int day) {
        return daysTimes.get(day);
    }

    @Override
    public int compareTo(FlightInfo other) {
        return code.compareTo(other.code);
    }
}
