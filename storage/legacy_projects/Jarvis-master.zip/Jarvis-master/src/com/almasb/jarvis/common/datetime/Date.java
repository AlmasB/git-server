package com.almasb.jarvis.common.datetime;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Date {

    private final int day;
    private final int month;
    private final int year;

    @JsonCreator
    public Date(@JsonProperty("day") int day, @JsonProperty("month") int month, @JsonProperty("year") int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public LocalDate toLocalDate() {
        return LocalDate.of(year, month, day);
    }

    @Override
    public String toString() {
        return toLocalDate().toString();
    }

    public static Date from(LocalDate date) {
        return new Date(date.getDayOfMonth(), date.getMonthValue(), date.getYear());
    }

    public static Date from(String date) {
        String[] tokens = date.split("/");
        int d = Integer.parseInt(tokens[0]);
        int m = Integer.parseInt(tokens[1]);
        int y = Integer.parseInt(tokens[2]);
        return new Date(d, m, y);
    }
}
