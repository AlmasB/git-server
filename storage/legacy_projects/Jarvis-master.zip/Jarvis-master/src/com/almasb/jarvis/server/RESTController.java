package com.almasb.jarvis.server;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.almasb.jarvis.common.api.DatesResponse;
import com.almasb.jarvis.common.api.EmptyResponse;
import com.almasb.jarvis.common.api.FlightInfoResponse;
import com.almasb.jarvis.common.api.OKResponse;
import com.almasb.jarvis.common.api.Response;
import com.almasb.jarvis.common.datetime.Date;
import com.almasb.jarvis.common.domain.FlightNotFoundException;

@RestController
public class RESTController {

    private final Log log = LogFactory.getLog(getClass());

    @Autowired
    private DataModel model;

    @RequestMapping(value = "/flights", method = RequestMethod.GET)
    public Response getDates() {
        model.populate();
        return new FlightInfoResponse(model.getFlights());
    }

    @RequestMapping(value = "/dates", method = RequestMethod.GET)
    public Response getDates(@RequestParam(value="src") String src,
            @RequestParam(value="dst") String dst) {

        try {
            Date[] dates = model.getDates(src, dst);
            return new DatesResponse(dates);
        }
        catch (FlightNotFoundException e) {
            e.printStackTrace();
        }

        return new EmptyResponse();
    }

    @RequestMapping(value = "/reserve", method = RequestMethod.GET)
    public Response reserve(@RequestParam(value="src") String src,
            @RequestParam(value="dst") String dst,
            @RequestParam(value="date") String date) {
        return new OKResponse();
    }
}
