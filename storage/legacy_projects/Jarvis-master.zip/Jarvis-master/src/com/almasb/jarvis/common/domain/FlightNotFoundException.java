package com.almasb.jarvis.common.domain;

public class FlightNotFoundException extends Exception {
    private static final long serialVersionUID = -2990795864692070083L;
}
