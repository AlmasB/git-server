package com.almasb.jarvis.common.api;

public class EmptyResponse implements Response {

}
