package com.almasb.jarvis.server;

import java.io.IOException;

import javafx.application.Application;
import javafx.application.Platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.almasb.jarvis.client.ClientApp;

@ComponentScan
@EnableAutoConfiguration
public class ServerApp {
    public static void main(String[] args) throws IOException {
        ApplicationContext ctx = SpringApplication.run(ServerApp.class, args);
        System.in.read();

        Application.launch(ClientApp.class, args);

        System.in.read();
        Platform.exit();
        SpringApplication.exit(ctx);
    }
}
