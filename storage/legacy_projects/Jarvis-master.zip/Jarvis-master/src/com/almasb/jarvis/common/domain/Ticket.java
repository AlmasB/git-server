package com.almasb.jarvis.common.domain;

import com.almasb.jarvis.common.datetime.Date;
import com.almasb.jarvis.common.datetime.Time;

public class Ticket {

    private final long id;
    private final String name;
    private final FlightInfo flightInfo;
    private final Date date;
    private final Time time;

    public Ticket(long id, String name, FlightInfo flightInfo,
            Date date, Time time) {
        this.id = id;
        this.name = name;
        this.flightInfo = flightInfo;
        this.date = date;
        this.time = time;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public FlightInfo getFlightInfo() {
        return flightInfo;
    }

    public Date getDate() {
        return date;
    }

    public Time getTime() {
        return time;
    }
}
