package com.almasb.jarvis.client;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;

import org.springframework.web.client.RestTemplate;

import com.almasb.jarvis.common.api.DatesResponse;
import com.almasb.jarvis.common.api.FailResponse;
import com.almasb.jarvis.common.api.FlightInfoResponse;
import com.almasb.jarvis.common.api.OKResponse;
import com.almasb.jarvis.common.api.Response;
import com.almasb.jarvis.common.datetime.Date;
import com.almasb.jarvis.common.domain.FlightInfo;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonTypeResolver;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

public class ClientController implements Initializable {

    private final RestTemplate restAccess = new RestTemplate();

    @FXML
    private ChoiceBox<String> sources;
    @FXML
    private ChoiceBox<String> destinations;

    @FXML
    private DatePicker datePicker;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        FlightInfoResponse response = restAccess.getForObject("http://127.0.0.1:8080/flights", FlightInfoResponse.class);
        FlightInfo[] flights = response.getFlights();
        for (FlightInfo flight : flights) {
            sources.getItems().add(flight.getSource());
            destinations.getItems().add(flight.getDestination());
        }

        sources.getSelectionModel().selectFirst();
        destinations.getSelectionModel().selectFirst();
    }

    public void search() {
        DatesResponse response = restAccess.getForObject(
                "http://127.0.0.1:8080/dates?src=" + sources.getSelectionModel().getSelectedItem()
                + "&dst=" + destinations.getSelectionModel().getSelectedItem(), DatesResponse.class);
        Date[] dates = response.getDates();

        datePicker.setDayCellFactory(date -> {
            return new DateCell() {
                @Override
                public void updateItem(LocalDate item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item.isBefore(LocalDate.now())) {
                        setDisable(true);
                    }
                    else {
                        if (!containsDate(dates, item)) {
                            setDisable(true);
                        }
                    }
                }
            };
        });
    }

    private boolean containsDate(Date[] dates, LocalDate d) {
        for (Date date : dates) {
            if (date.toLocalDate().equals(d)) {
                return true;
            }
        }

        return false;
    }

    public void reserve() {
        ObjectMapper mapper = new ObjectMapper();
        //Response response = restAccess.getForObject("http://127.0.0.1:8080/reserve?src=dd&dst=dd&date=dd", Response.class);

        mapper.enableDefaultTyping(); // defaults for defaults (see below); include as wrapper-array, non-concrete types
        mapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL, JsonTypeInfo.As.WRAPPER_OBJECT); // all non-final types


        Response response = null;
        try {
            response = mapper.readValue(new URL("http://127.0.0.1:8080/reserve?src=dd&dst=dd&date=dd"), OKResponse.class);
            System.out.println(response.getClass());
        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println("fail");
    }
}
