package com.almasb.jarvis.common.datetime;

import java.time.LocalTime;

public class Time {

    private final int hour;
    private final int minute;

    public Time(int hour, int minute) {
        this.hour = hour;
        this.minute = minute;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public LocalTime toLocalTime() {
        return LocalTime.of(hour, minute);
    }
}
