package com.almasb.jarvis.common.api;

import com.almasb.jarvis.common.domain.FlightInfo;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FlightInfoResponse implements Response {

    private final FlightInfo[] flights;

    @JsonCreator
    public FlightInfoResponse(@JsonProperty("flights") FlightInfo[] flights) {
        this.flights = flights;
    }

    public FlightInfo[] getFlights() {
        return flights;
    }
}
