package com.almasb.jarvis.common.api;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
public class OKResponse implements Response {

    private String field = String.valueOf(System.currentTimeMillis());

    public void setField(String s) {
        field = s;
    }

    public String getField() {
        return field;
    }

    public void test() {
        System.out.println(field);
    }
}
