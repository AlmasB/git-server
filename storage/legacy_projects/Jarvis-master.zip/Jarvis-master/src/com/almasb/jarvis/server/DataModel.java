package com.almasb.jarvis.server;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.almasb.jarvis.common.datetime.Date;
import com.almasb.jarvis.common.datetime.Time;
import com.almasb.jarvis.common.domain.FlightInfo;
import com.almasb.jarvis.common.domain.FlightNotFoundException;

@Component
public class DataModel {

    private List<FlightInfo> timetable = new ArrayList<>();

    /**
     * K - flight code + "$" + date
     * V - number of tickets available
     */
    private Map<String, Integer> tickets = new HashMap<>();

    private FlightInfo getFlightInfo(String source, String destination) throws FlightNotFoundException {
        return timetable.stream()
                .filter(flight -> flight.isSameRoute(source, destination))
                .findAny()
                .orElseThrow(FlightNotFoundException::new);
    }

    public FlightInfo[] getFlights() {
        return timetable.toArray(new FlightInfo[0]);
    }

    public Date[] getDates(String source, String destination) throws FlightNotFoundException {
        FlightInfo flight = getFlightInfo(source, destination);
        Integer[] days = flight.getDays();

        List<Date> dates = new ArrayList<>();

        LocalDate now = LocalDate.now();
        for (int day = 0; day < 90; day++) {
            LocalDate date = now.plusDays(day);

            for (int d : days) {
                if (date.getDayOfWeek().getValue() == d) {
                    if (isTicketAvailable(flight.getCode(), Date.from(date))) {
                        dates.add(Date.from(date));
                        break;
                    }
                }
            }
        }

        return dates.toArray(new Date[0]);
    }

    public void populate() {
        // TEST DATA
        FlightInfo flight = new FlightInfo("XYZ123", "XCITY", "YCITY")
                            .addDaysTimes(1, new Time(13, 00))
                            .addDaysTimes(3, new Time(20, 30))
                            .addDaysTimes(7, new Time(15, 25));
        timetable.add(flight);

        LocalDate now = LocalDate.now();
        for (int day = 0; day < 90; day++) {
            LocalDate date = now.plusDays(day);

            for (int d : flight.getDays()) {
                if (date.getDayOfWeek().getValue() == d) {
                    tickets.put(flight.getCode() + "$" + date.toString(), 30);
                    break;
                }
            }
        }

        // 2

        flight = new FlightInfo("XYZ125", "ACITY", "BCITY")
                    .addDaysTimes(2, new Time(13, 00))
                    .addDaysTimes(3, new Time(20, 30))
                    .addDaysTimes(6, new Time(15, 25));
        timetable.add(flight);

        now = LocalDate.now();
        for (int day = 0; day < 90; day++) {
            LocalDate date = now.plusDays(day);

            for (int d : flight.getDays()) {
                if (date.getDayOfWeek().getValue() == d) {
                    tickets.put(flight.getCode() + "$" + date.toString(), 30);
                    break;
                }
            }
        }
    }

    private boolean isTicketAvailable(String flightCode, Date date) {
        return tickets.getOrDefault(flightCode + "$" + date.toString(), 0) > 0;
    }
}
