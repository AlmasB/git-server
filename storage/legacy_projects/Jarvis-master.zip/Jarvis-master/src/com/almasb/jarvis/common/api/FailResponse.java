package com.almasb.jarvis.common.api;

public class FailResponse implements Response {

}
