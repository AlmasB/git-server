# JMessenger
A simple chat application
