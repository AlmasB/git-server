window.onload = init;

function init() {
	document.getElementById("btn1").onclick = function() {
		main();
	}
}

function inputValid(w, h) {
	if (w < 10 || h < 11 || h % 2 == 0 || w % 2 != 0)
		return false;

	return true;
}

function drawLine(width, pos) {
	var prDiabolo = false; 
	var line = "";
	
	for (var i = 0; i < width; i++)
	{
		if (i == pos)          {prDiabolo = true;}
		if (i == width - pos)  {prDiabolo = false;}
	
		line += prDiabolo ? "@" : ".";
	}
	
	return line;
}

function draw(width, height) {
	var state = 0;	//0 - shrink, 1 - grow, 2 - fixed
	var pos = -1;
	var lines = new Array(height);
	
	for (var i = 0; i < height; i++)
	{  
		if (width - (pos)*2 == 2) {state = 2;}
		if (height - i == pos)    {state = 1;}   //because it needs at least 'pos' lines to finish

		switch (state)                            
		{
			case 0: 
			pos++; break;

			case 1: 
			pos--; break;  
		}
		
		lines[i] = drawLine(width, pos);
	}
	
	return lines;
}

function main() {	
	var width = document.form1.box1.value;
	var height = document.form1.box2.value;
	var lines = new Array(height);
	
	if (inputValid(width, height))
		lines = draw(width, height);
	else
	{
		alert("Input is invalid");
		return;
	}
		
	var mydiv = document.getElementById("divi");
	var children = mydiv.childNodes;
	
	while (children.length > 0)
		mydiv.removeChild(children[0]);
		
	for (var i = 0; i < height; i++)
	{
		var elem = document.createElement("p");
		elem.style.fontFamily = "Courier";
		elem.appendChild(document.createTextNode(lines[i]));
		mydiv.appendChild(elem);
	}
}
