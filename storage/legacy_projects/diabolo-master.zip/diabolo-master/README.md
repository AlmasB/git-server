diabolo
=======

just a test really, draw a diabolo with given width and height in js
